export type Role = 'STUDENT' | 'HOD' | 'WARDEN';

export type OutpassStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED';

export type OutpassReason = 
  | 'Medical Emergency'
  | 'Family Emergency'
  | 'Personal Work'
  | 'Home Visit'
  | 'Official College Work'
  | 'Campus Placement / Internship'
  | 'Other';

export interface StudentProfile {
  id: string;
  collegeId: string;
  name: string;
  department: string;
  program: string;
  academicYear: string;
  semester: string;
  section: string;
  attendancePercentage: number;
  cgpa: number;
  backlogs: number;
  currentCredits: number;
  email: string;
  phone: string;
  parentName: string;
  parentPhone: string;
  hostelRoom: string;
  hostelBlock: string;
  mentorName: string;
  mentorPhone: string;
  avatarUrl: string;
}

export interface StaffProfile {
  id: string;
  staffId: string;
  name: string;
  designation: string;
  department: string;
  role: 'HOD' | 'WARDEN';
  email: string;
  phone: string;
}

export interface OutpassApprovalRecord {
  id: string;
  outpassId: string;
  staffName: string;
  staffRole: 'HOD' | 'WARDEN';
  action: 'APPROVED' | 'REJECTED';
  timestamp: string;
  remarks: string;
}

export interface OutpassRequest {
  id: string;
  requestNumber: string; // e.g. HITAM-OP-2026-0841
  studentId: string;
  studentName: string;
  collegeId: string;
  department: string;
  academicYear: string;
  semester: string;
  reason: OutpassReason;
  destination: string;
  outpassDate: string; // YYYY-MM-DD
  leavingTime: string; // HH:MM
  expectedReturnDate: string; // YYYY-MM-DD
  expectedReturnTime: string; // HH:MM
  parentContact: string;
  additionalExplanation: string;
  supportingDocName?: string;
  status: OutpassStatus;
  submissionDate: string;
  hodApproval?: {
    approved: boolean;
    staffName: string;
    remarks: string;
    timestamp: string;
  };
  wardenApproval?: {
    approved: boolean;
    staffName: string;
    remarks: string;
    timestamp: string;
  };
  approvalHistory: OutpassApprovalRecord[];
  qrToken?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ALERT';
  relatedOutpassId?: string;
}

export interface CollegeAnnouncement {
  id: string;
  title: string;
  category: 'Academics' | 'Hostel' | 'Examination' | 'General';
  date: string;
  content: string;
  important: boolean;
}
