export interface JavaProjectFile {
  path: string;
  category: 'Configuration' | 'Database' | 'Model' | 'Repository' | 'Service' | 'Controller' | 'Security' | 'Documentation';
  description: string;
  code: string;
}

export const JAVA_PROJECT_FILES: JavaProjectFile[] = [
  {
    path: 'pom.xml',
    category: 'Configuration',
    description: 'Maven Project Object Model: Defines Java 17, Spring Boot 3.2.x parent, MySQL connector, Spring Data JPA, Validation, and Spring Security dependencies.',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" 
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
                             https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.5</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    
    <groupId>in.hitam</groupId>
    <artifactId>hitam-outpass</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <name>HITAM Smart Outpass Management System</name>
    <description>College Outpass System for Hyderabad Institute of Technology and Management</description>
    
    <properties>
        <java.version>17</java.version>
    </properties>
    
    <dependencies>
        <!-- Spring Boot Web Starter (Embedded Tomcat, RESTful APIs) -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        
        <!-- Spring Data JPA (Hibernate ORM for MySQL) -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        
        <!-- MySQL JDBC Connector Driver -->
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <scope>runtime</scope>
        </dependency>
        
        <!-- Bean Validation (Hibernate Validator for @NotBlank, @Future, etc.) -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        
        <!-- Spring Security & BCrypt Password Hashing -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>

        <!-- JSON Web Token (jjwt) for stateless REST authentication -->
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-api</artifactId>
            <version>0.11.5</version>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-impl</artifactId>
            <version>0.11.5</version>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-jackson</artifactId>
            <version>0.11.5</version>
            <scope>runtime</scope>
        </dependency>

        <!-- DevTools for automatic server reload during development -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>

        <!-- Testing framework -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
    
    <build>
        <plugins>
            <!-- Spring Boot Maven Plugin creates an executable fat JAR -->
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>`
  },
  {
    path: 'src/main/resources/application.properties',
    category: 'Configuration',
    description: 'Spring Boot configuration file: MySQL database connection parameters, HikariCP pool, Hibernate dialect, and server port 8080.',
    code: `# ===================================================================
# HITAM Smart Outpass Management System - Application Configuration
# ===================================================================

server.port=8080

# Spring Application Name
spring.application.name=hitam-outpass-backend

# MySQL Community Server Connection URL (Localhost, port 3306)
spring.datasource.url=jdbc:mysql://localhost:3306/hitam_outpass_db?useSSL=false&serverTimezone=Asia/Kolkata&allowPublicKeyRetrieval=true
spring.datasource.username=root
# Change this to your local MySQL root password:
spring.datasource.password=root123
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# HikariCP Connection Pool Settings
spring.datasource.hikari.maximum-pool-size=10
spring.datasource.hikari.minimum-idle=2
spring.datasource.hikari.idle-timeout=30000

# Hibernate JPA Settings
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

# JWT Security Secret & Expiration (24 Hours)
jwt.secret=9a3f2c5e8b1d4a7f0e3c6b9d2a5f8e1b4d7a0c3f6e9b2d5a8c1f4e7b0d3a6c9
jwt.expiration-ms=86400000

# File Upload Limit for Outpass Supporting Documents
spring.servlet.multipart.max-file-size=5MB
spring.servlet.multipart.max-request-size=5MB`
  },
  {
    path: 'database/schema.sql',
    category: 'Database',
    description: 'Complete MySQL DDL & DML: Creates database, students, staff, outpass_requests, notifications, and outpass_approval_history tables with sample records.',
    code: `-- ===============================================================
-- HITAM SMART OUTPASS MANAGEMENT SYSTEM - DATABASE CREATION SCRIPT
-- Tested on MySQL Community Server 8.0+
-- ===============================================================

CREATE DATABASE IF NOT EXISTS hitam_outpass_db 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE hitam_outpass_db;

-- 1. Students Table
CREATE TABLE IF NOT EXISTS students (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    college_id VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    department VARCHAR(50) NOT NULL,
    program VARCHAR(50) NOT NULL DEFAULT 'B.Tech - AIML',
    academic_year VARCHAR(20) NOT NULL DEFAULT '2nd Year',
    semester VARCHAR(20) NOT NULL DEFAULT 'Semester IV',
    section VARCHAR(5) DEFAULT 'A',
    attendance_pct DECIMAL(5,2) NOT NULL DEFAULT 85.00,
    cgpa DECIMAL(4,2) NOT NULL DEFAULT 8.00,
    backlogs INT NOT NULL DEFAULT 0,
    credits INT NOT NULL DEFAULT 21,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    parent_name VARCHAR(100) NOT NULL,
    parent_phone VARCHAR(15) NOT NULL,
    hostel_room VARCHAR(50),
    hostel_block VARCHAR(50),
    mentor_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_college_id (college_id)
) ENGINE=InnoDB;

-- 2. Staff Table (HOD & Wardens)
CREATE TABLE IF NOT EXISTS staff (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    staff_id VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    department VARCHAR(50) NOT NULL,
    role ENUM('HOD', 'WARDEN') NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Outpass Requests Table
CREATE TABLE IF NOT EXISTS outpass_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_number VARCHAR(30) NOT NULL UNIQUE,
    student_id BIGINT NOT NULL,
    reason VARCHAR(50) NOT NULL,
    destination VARCHAR(200) NOT NULL,
    outpass_date DATE NOT NULL,
    leaving_time TIME NOT NULL,
    expected_return_date DATE NOT NULL,
    expected_return_time TIME NOT NULL,
    parent_contact VARCHAR(15) NOT NULL,
    additional_explanation TEXT,
    supporting_doc_name VARCHAR(255),
    status ENUM('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED') NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_request_number (request_number)
) ENGINE=InnoDB;

-- 4. Outpass Approval History (Audit Trail)
CREATE TABLE IF NOT EXISTS outpass_approval_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    outpass_id BIGINT NOT NULL,
    staff_id BIGINT NOT NULL,
    action ENUM('APPROVED', 'REJECTED') NOT NULL,
    remarks TEXT,
    action_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (outpass_id) REFERENCES outpass_requests(id) ON DELETE CASCADE,
    FOREIGN KEY (staff_id) REFERENCES staff(id)
) ENGINE=InnoDB;

-- 5. Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('INFO', 'SUCCESS', 'WARNING', 'ALERT') NOT NULL DEFAULT 'INFO',
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ===============================================================
-- SEED SAMPLE DATA (Passwords hashed with BCrypt for 'hitam@123')
-- ===============================================================

-- Student: 23M41A6601 (Srivally Thandury)
INSERT INTO students (college_id, full_name, department, program, academic_year, semester, attendance_pct, cgpa, backlogs, credits, email, password_hash, phone, parent_name, parent_phone, hostel_room, hostel_block, mentor_name)
VALUES (
    '23M41A6601', 
    'Srivally Thandury', 
    'Artificial Intelligence & Machine Learning', 
    'B.Tech - AIML', 
    '2nd Year', 
    'Semester IV', 
    88.50, 
    8.74, 
    0, 
    21, 
    'srivallythandury@hitam.edu.in', 
    '$2a$10$vI8aWBnW3fID.ZQ4/ZO1G.q1qK92x4u3B4uK4nJ/7j7T6vP6W0.iO', -- Password: 'password123'
    '+91 98765 43210', 
    'R. K. Thandury', 
    '+91 94401 23456', 
    'Room 304, Parijatha', 
    'Girls Hostel Block B', 
    'Dr. K. Radhika'
) ON DUPLICATE KEY UPDATE full_name=full_name;

-- Staff: HOD (Dr. P. Suresh Kumar)
INSERT INTO staff (staff_id, full_name, designation, department, role, email, password_hash, phone)
VALUES (
    'HOD-AIML', 
    'Dr. P. Suresh Kumar', 
    'Professor & Head of Department', 
    'Dept of AIML', 
    'HOD', 
    'hod.aiml@hitam.edu.in', 
    '$2a$10$vI8aWBnW3fID.ZQ4/ZO1G.q1qK92x4u3B4uK4nJ/7j7T6vP6W0.iO', 
    '+91 94900 12345'
) ON DUPLICATE KEY UPDATE full_name=full_name;

-- Staff: Chief Warden (Col. R. K. Sharma)
INSERT INTO staff (staff_id, full_name, designation, department, role, email, password_hash, phone)
VALUES (
    'WARDEN-01', 
    'Col. R. K. Sharma', 
    'Chief Hostel Warden', 
    'Hostel Administration', 
    'WARDEN', 
    'warden@hitam.edu.in', 
    '$2a$10$vI8aWBnW3fID.ZQ4/ZO1G.q1qK92x4u3B4uK4nJ/7j7T6vP6W0.iO', 
    '+91 94900 54321'
) ON DUPLICATE KEY UPDATE full_name=full_name;`
  },
  {
    path: 'src/main/java/in/hitam/outpass/OutpassApplication.java',
    category: 'Configuration',
    description: 'Spring Boot main entry point with @SpringBootApplication annotation that boots embedded Tomcat server.',
    code: `package in.hitam.outpass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * HITAM Smart Outpass Management System
 * Main Spring Boot Application Bootstrap Class
 * 
 * @author HITAM AIML Engineering Student
 * @version 1.0.0
 */
@SpringBootApplication
public class OutpassApplication {

    public static void main(String[] args) {
        SpringApplication.run(OutpassApplication.class, args);
        System.out.println("==================================================");
        System.out.println(" HITAM Smart Outpass System Started Successfully! ");
        System.out.println(" Access URL: http://localhost:8080               ");
        System.out.println("==================================================");
    }
}`
  },
  {
    path: 'src/main/java/in/hitam/outpass/model/OutpassRequest.java',
    category: 'Model',
    description: 'JPA Entity representing an outpass request with relational mappings, timestamps, and validation constraints.',
    code: `package in.hitam.outpass.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "outpass_requests")
public class OutpassRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "request_number", unique = true, nullable = false, length = 30)
    private String requestNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @NotBlank(message = "Outpass reason is mandatory")
    @Column(name = "reason", nullable = false, length = 50)
    private String reason;

    @NotBlank(message = "Destination is mandatory")
    @Column(name = "destination", nullable = false, length = 200)
    private String destination;

    @NotNull(message = "Outpass date is mandatory")
    @Column(name = "outpass_date", nullable = false)
    private LocalDate outpassDate;

    @NotNull(message = "Leaving time is mandatory")
    @Column(name = "leaving_time", nullable = false)
    private LocalTime leavingTime;

    @NotNull(message = "Expected return date is mandatory")
    @Column(name = "expected_return_date", nullable = false)
    private LocalDate expectedReturnDate;

    @NotNull(message = "Expected return time is mandatory")
    @Column(name = "expected_return_time", nullable = false)
    private LocalTime expectedReturnTime;

    @NotBlank(message = "Parent contact number is mandatory")
    @Column(name = "parent_contact", nullable = false, length = 15)
    private String parentContact;

    @Column(name = "additional_explanation", columnDefinition = "TEXT")
    private String additionalExplanation;

    @Column(name = "supporting_doc_name")
    private String supportingDocName;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private OutpassStatus status = OutpassStatus.PENDING;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @OneToMany(mappedBy = "outpassRequest", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OutpassApprovalHistory> approvalHistory = new ArrayList<>();

    public enum OutpassStatus {
        PENDING, APPROVED, REJECTED, CANCELLED
    }

    // Default Constructor
    public OutpassRequest() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRequestNumber() { return requestNumber; }
    public void setRequestNumber(String requestNumber) { this.requestNumber = requestNumber; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public LocalDate getOutpassDate() { return outpassDate; }
    public void setOutpassDate(LocalDate outpassDate) { this.outpassDate = outpassDate; }

    public LocalTime getLeavingTime() { return leavingTime; }
    public void setLeavingTime(LocalTime leavingTime) { this.leavingTime = leavingTime; }

    public LocalDate getExpectedReturnDate() { return expectedReturnDate; }
    public void setExpectedReturnDate(LocalDate expectedReturnDate) { this.expectedReturnDate = expectedReturnDate; }

    public LocalTime getExpectedReturnTime() { return expectedReturnTime; }
    public void setExpectedReturnTime(LocalTime expectedReturnTime) { this.expectedReturnTime = expectedReturnTime; }

    public String getParentContact() { return parentContact; }
    public void setParentContact(String parentContact) { this.parentContact = parentContact; }

    public String getAdditionalExplanation() { return additionalExplanation; }
    public void setAdditionalExplanation(String additionalExplanation) { this.additionalExplanation = additionalExplanation; }

    public String getSupportingDocName() { return supportingDocName; }
    public void setSupportingDocName(String supportingDocName) { this.supportingDocName = supportingDocName; }

    public OutpassStatus getStatus() { return status; }
    public void setStatus(OutpassStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public List<OutpassApprovalHistory> getApprovalHistory() { return approvalHistory; }
    public void setApprovalHistory(List<OutpassApprovalHistory> approvalHistory) { this.approvalHistory = approvalHistory; }
}`
  },
  {
    path: 'src/main/java/in/hitam/outpass/model/Student.java',
    category: 'Model',
    description: 'JPA Entity representing a student enrolled at HITAM with academic metrics, attendance, and roll number.',
    code: `package in.hitam.outpass.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "college_id", unique = true, nullable = false, length = 20)
    private String collegeId;

    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @Column(name = "department", nullable = false, length = 50)
    private String department;

    @Column(name = "program", nullable = false, length = 50)
    private String program;

    @Column(name = "academic_year", nullable = false, length = 20)
    private String academicYear;

    @Column(name = "semester", nullable = false, length = 20)
    private String semester;

    @Column(name = "attendance_pct", precision = 5, scale = 2)
    private BigDecimal attendancePercentage;

    @Column(name = "cgpa", precision = 4, scale = 2)
    private BigDecimal cgpa;

    @Column(name = "backlogs")
    private Integer backlogs = 0;

    @Column(name = "credits")
    private Integer credits = 21;

    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Column(name = "phone", nullable = false)
    private String phone;

    @Column(name = "parent_name", nullable = false)
    private String parentName;

    @Column(name = "parent_phone", nullable = false)
    private String parentPhone;

    @Column(name = "hostel_room")
    private String hostelRoom;

    @Column(name = "hostel_block")
    private String hostelBlock;

    @Column(name = "mentor_name")
    private String mentorName;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Student() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCollegeId() { return collegeId; }
    public void setCollegeId(String collegeId) { this.collegeId = collegeId; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getProgram() { return program; }
    public void setProgram(String program) { this.program = program; }
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    public BigDecimal getAttendancePercentage() { return attendancePercentage; }
    public void setAttendancePercentage(BigDecimal attendancePercentage) { this.attendancePercentage = attendancePercentage; }
    public BigDecimal getCgpa() { return cgpa; }
    public void setCgpa(BigDecimal cgpa) { this.cgpa = cgpa; }
    public Integer getBacklogs() { return backlogs; }
    public void setBacklogs(Integer backlogs) { this.backlogs = backlogs; }
    public Integer getCredits() { return credits; }
    public void setCredits(Integer credits) { this.credits = credits; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getParentName() { return parentName; }
    public void setParentName(String parentName) { this.parentName = parentName; }
    public String getParentPhone() { return parentPhone; }
    public void setParentPhone(String parentPhone) { this.parentPhone = parentPhone; }
    public String getHostelRoom() { return hostelRoom; }
    public void setHostelRoom(String hostelRoom) { this.hostelRoom = hostelRoom; }
    public String getHostelBlock() { return hostelBlock; }
    public void setHostelBlock(String hostelBlock) { this.hostelBlock = hostelBlock; }
    public String getMentorName() { return mentorName; }
    public void setMentorName(String mentorName) { this.mentorName = mentorName; }
}`
  },
  {
    path: 'src/main/java/in/hitam/outpass/repository/OutpassRepository.java',
    category: 'Repository',
    description: 'Spring Data JPA Repository with derived query methods and custom queries for outpass records.',
    code: `package in.hitam.outpass.repository;

import in.hitam.outpass.model.OutpassRequest;
import in.hitam.outpass.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OutpassRepository extends JpaRepository<OutpassRequest, Long> {

    // Retrieve all outpass requests for a specific student sorted by newest first
    List<OutpassRequest> findByStudentOrderByCreatedAtDesc(Student student);

    // Retrieve by unique request number
    Optional<OutpassRequest> findByRequestNumber(String requestNumber);

    // Retrieve all pending requests for staff review
    List<OutpassRequest> findByStatusOrderByCreatedAtAsc(OutpassRequest.OutpassStatus status);

    // Count pending requests for a specific student
    long countByStudentAndStatus(Student student, OutpassRequest.OutpassStatus status);

    // Search outpass by student ID or request number
    @Query("SELECT o FROM OutpassRequest o WHERE o.requestNumber LIKE %:query% OR o.student.collegeId LIKE %:query%")
    List<OutpassRequest> searchRequests(@Param("query") String query);
}`
  },
  {
    path: 'src/main/java/in/hitam/outpass/service/OutpassService.java',
    category: 'Service',
    description: 'Business logic layer enforcing validation (return date > departure, unique request numbers, status changes, and notification dispatches).',
    code: `package in.hitam.outpass.service;

import in.hitam.outpass.model.*;
import in.hitam.outpass.repository.NotificationRepository;
import in.hitam.outpass.repository.OutpassRepository;
import in.hitam.outpass.repository.StudentRepository;
import in.hitam.outpass.repository.StaffRepository;
import in.hitam.outpass.dto.OutpassApplyDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Service
public class OutpassService {

    private final OutpassRepository outpassRepository;
    private final StudentRepository studentRepository;
    private final StaffRepository staffRepository;
    private final NotificationRepository notificationRepository;

    public OutpassService(OutpassRepository outpassRepository,
                          StudentRepository studentRepository,
                          StaffRepository staffRepository,
                          NotificationRepository notificationRepository) {
        this.outpassRepository = outpassRepository;
        this.studentRepository = studentRepository;
        this.staffRepository = staffRepository;
        this.notificationRepository = notificationRepository;
    }

    @Transactional
    public OutpassRequest submitOutpass(String collegeId, OutpassApplyDto dto) {
        Student student = studentRepository.findByCollegeId(collegeId)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + collegeId));

        // Validation: Expected return date/time must be strictly after departure
        LocalDateTime departure = LocalDateTime.of(dto.getOutpassDate(), dto.getLeavingTime());
        LocalDateTime returnTime = LocalDateTime.of(dto.getExpectedReturnDate(), dto.getExpectedReturnTime());

        if (returnTime.isBefore(departure) || returnTime.isEqual(departure)) {
            throw new IllegalArgumentException("Expected return date and time must be strictly after departure time.");
        }

        OutpassRequest request = new OutpassRequest();
        request.setStudent(student);
        request.setReason(dto.getReason());
        request.setDestination(dto.getDestination());
        request.setOutpassDate(dto.getOutpassDate());
        request.setLeavingTime(dto.getLeavingTime());
        request.setExpectedReturnDate(dto.getExpectedReturnDate());
        request.setExpectedReturnTime(dto.getExpectedReturnTime());
        request.setParentContact(dto.getParentContact());
        request.setAdditionalExplanation(dto.getAdditionalExplanation());
        request.setStatus(OutpassRequest.OutpassStatus.PENDING);

        // Generate unique request number format: HITAM-OP-2026-XXXX
        int randomSuffix = 1000 + new Random().nextInt(9000);
        request.setRequestNumber("HITAM-OP-2026-" + randomSuffix);

        OutpassRequest saved = outpassRepository.save(request);

        // Create student notification
        Notification notification = new Notification();
        notification.setStudent(student);
        notification.setTitle("Outpass Request Submitted");
        notification.setMessage("Your outpass request " + saved.getRequestNumber() + " is currently under HOD/Warden review.");
        notification.setType(Notification.NotificationType.INFO);
        notificationRepository.save(notification);

        return saved;
    }

    @Transactional
    public OutpassRequest processStaffDecision(Long outpassId, String staffId, boolean approved, String remarks) {
        OutpassRequest outpass = outpassRepository.findById(outpassId)
                .orElseThrow(() -> new RuntimeException("Outpass request not found: " + outpassId));

        Staff staff = staffRepository.findByStaffId(staffId)
                .orElseThrow(() -> new RuntimeException("Staff member not found: " + staffId));

        outpass.setStatus(approved ? OutpassRequest.OutpassStatus.APPROVED : OutpassRequest.OutpassStatus.REJECTED);

        OutpassApprovalHistory history = new OutpassApprovalHistory();
        history.setOutpassRequest(outpass);
        history.setStaff(staff);
        history.setAction(approved ? OutpassApprovalHistory.Action.APPROVED : OutpassApprovalHistory.Action.REJECTED);
        history.setRemarks(remarks);
        history.setActionTimestamp(LocalDateTime.now());
        outpass.getApprovalHistory().add(history);

        OutpassRequest updated = outpassRepository.save(outpass);

        // Send notification to student
        Notification notification = new Notification();
        notification.setStudent(outpass.getStudent());
        notification.setTitle(approved ? "Outpass Approved!" : "Outpass Rejected");
        notification.setMessage("Your request " + outpass.getRequestNumber() + " was " 
                + (approved ? "APPROVED" : "REJECTED") + " by " + staff.getFullName() 
                + ". Remarks: " + remarks);
        notification.setType(approved ? Notification.NotificationType.SUCCESS : Notification.NotificationType.ALERT);
        notificationRepository.save(notification);

        return updated;
    }
}`
  },
  {
    path: 'src/main/java/in/hitam/outpass/controller/OutpassController.java',
    category: 'Controller',
    description: 'REST Controller providing student API endpoints for applying, viewing history, and tracking approval status.',
    code: `package in.hitam.outpass.controller;

import in.hitam.outpass.dto.OutpassApplyDto;
import in.hitam.outpass.model.OutpassRequest;
import in.hitam.outpass.model.Student;
import in.hitam.outpass.repository.OutpassRepository;
import in.hitam.outpass.repository.StudentRepository;
import in.hitam.outpass.service.OutpassService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/outpasses")
@CrossOrigin(origins = "*")
public class OutpassController {

    private final OutpassService outpassService;
    private final OutpassRepository outpassRepository;
    private final StudentRepository studentRepository;

    public OutpassController(OutpassService outpassService, 
                             OutpassRepository outpassRepository,
                             StudentRepository studentRepository) {
        this.outpassService = outpassService;
        this.outpassRepository = outpassRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * Submit a new Outpass request
     */
    @PostMapping
    public ResponseEntity<?> applyOutpass(@Valid @RequestBody OutpassApplyDto dto, Authentication auth) {
        String collegeId = auth.getName(); // Extracted from JWT token
        OutpassRequest created = outpassService.submitOutpass(collegeId, dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    /**
     * Get Outpass history of the logged-in student
     */
    @GetMapping
    public ResponseEntity<List<OutpassRequest>> getMyOutpasses(Authentication auth) {
        String collegeId = auth.getName();
        Student student = studentRepository.findByCollegeId(collegeId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return ResponseEntity.ok(outpassRepository.findByStudentOrderByCreatedAtDesc(student));
    }

    /**
     * View details of a specific Outpass request
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getOutpassById(@PathVariable Long id, Authentication auth) {
        OutpassRequest request = outpassRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Outpass request not found"));
        
        // Authorization check: Students can only view their own requests
        if (!request.getStudent().getCollegeId().equals(auth.getName())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied.");
        }
        return ResponseEntity.ok(request);
    }
}`
  },
  {
    path: 'src/main/java/in/hitam/outpass/config/SecurityConfig.java',
    category: 'Security',
    description: 'Spring Security 6 configuration with BCryptPasswordEncoder, CORS policy, and Role-Based Access Control (RBAC).',
    code: `package in.hitam.outpass.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> cors.configure(http))
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // Public endpoints
                .requestMatchers("/api/auth/**", "/", "/index.html", "/static/**", "/css/**", "/js/**").permitAll()
                // Staff-only endpoints
                .requestMatchers("/api/staff/**").hasAnyRole("HOD", "WARDEN")
                // Student endpoints
                .requestMatchers("/api/outpasses/**", "/api/students/**").hasRole("STUDENT")
                .anyRequest().authenticated()
            );

        return http.build();
    }
}`
  },
  {
    path: 'README.md',
    category: 'Documentation',
    description: 'Beginner-friendly step-by-step setup guide for Windows, VS Code, MySQL, and Maven terminal commands.',
    code: `# HITAM Smart Outpass Management System
## Full-Stack College Project (Spring Boot 3 + MySQL + HTML5/CSS3/JS)

Built for Hyderabad Institute of Technology and Management (HITAM).

---

### Prerequisites Checklist:
1. **Java JDK 17** installed (\`java -version\`)
2. **Apache Maven 3.8+** installed (\`mvn -version\`)
3. **MySQL Community Server 8.0+** running on port \`3306\`
4. **Visual Studio Code** with "Extension Pack for Java"

---

### Step-by-Step Setup Guide for Windows & VS Code:

#### Step 1: Clone or Extract the Project
Open VS Code, press \`Ctrl + ~\`, and open your terminal.

#### Step 2: Set Up MySQL Database
Open MySQL Command Line Client or MySQL Workbench and run:
\`\`\`sql
source database/schema.sql;
\`\`\`
Or execute the script in \`database/schema.sql\` to create the database \`hitam_outpass_db\` and populate seed records.

#### Step 3: Configure Database Credentials
Open \`src/main/resources/application.properties\` and verify:
\`\`\`properties
spring.datasource.url=jdbc:mysql://localhost:3306/hitam_outpass_db
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD
\`\`\`

#### Step 4: Build with Maven
In the VS Code terminal at project root, execute:
\`\`\`bash
mvn clean install -DskipTests
\`\`\`

#### Step 5: Run Spring Boot Application
\`\`\`bash
mvn spring-boot:run
\`\`\`
The application starts at: **http://localhost:8080**

---

### Default Test Credentials:
* **Student Login:** Roll: \`23M41A6601\`, Password: \`password123\`
* **HOD Login:** Staff ID: \`HOD-AIML\`, Password: \`password123\`
* **Warden Login:** Staff ID: \`WARDEN-01\`, Password: \`password123\`
`
  }
];
