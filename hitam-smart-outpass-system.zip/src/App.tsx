/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Leaf, 
  BookOpen, 
  Sparkles, 
  Code2, 
  ShieldCheck, 
  Calendar,
  ExternalLink
} from 'lucide-react';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { StudentDashboard } from './components/StudentDashboard';
import { ApplyOutpassForm } from './components/ApplyOutpassForm';
import { OutpassHistory } from './components/OutpassHistory';
import { StaffApprovalView } from './components/StaffApprovalView';
import { ProfileView } from './components/ProfileView';
import { CollegeAcademicView } from './components/CollegeAcademicView';
import { NotificationsView } from './components/NotificationsView';
import { JavaCodeRepoView } from './components/JavaCodeRepoView';
import { SyllabusHubView } from './components/SyllabusHubView';
import { TeacherGuideModal } from './components/TeacherGuideModal';
import { AuthModal } from './components/AuthModal';

import { 
  Role, 
  StudentProfile, 
  StaffProfile, 
  OutpassRequest, 
  NotificationItem, 
  CollegeAnnouncement 
} from './types';

import { 
  INITIAL_STUDENT, 
  INITIAL_STAFF_MEMBERS, 
  INITIAL_OUTPASS_REQUESTS, 
  INITIAL_NOTIFICATIONS, 
  COLLEGE_ANNOUNCEMENTS 
} from './data/mockData';

export default function App() {
  // Persistent State with LocalStorage
  const [student, setStudent] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('hitam_student');
    return saved ? JSON.parse(saved) : INITIAL_STUDENT;
  });

  const [outpasses, setOutpasses] = useState<OutpassRequest[]>(() => {
    const saved = localStorage.getItem('hitam_outpasses');
    return saved ? JSON.parse(saved) : INITIAL_OUTPASS_REQUESTS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('hitam_notifs');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [announcements] = useState<CollegeAnnouncement[]>(COLLEGE_ANNOUNCEMENTS);
  const [staffMembers] = useState<StaffProfile[]>(INITIAL_STAFF_MEMBERS);

  // App Navigation & Role State
  const [currentRole, setCurrentRole] = useState<Role>('STUDENT');
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [activeStaffRole, setActiveStaffRole] = useState<'HOD' | 'WARDEN'>('HOD');

  // Modals & UI State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(true);

  // Save to LocalStorage whenever critical data changes
  useEffect(() => {
    localStorage.setItem('hitam_student', JSON.stringify(student));
  }, [student]);

  useEffect(() => {
    localStorage.setItem('hitam_outpasses', JSON.stringify(outpasses));
  }, [outpasses]);

  useEffect(() => {
    localStorage.setItem('hitam_notifs', JSON.stringify(notifications));
  }, [notifications]);

  // Outpass Handlers
  const handleApplyOutpass = (newRequest: OutpassRequest) => {
    setOutpasses(prev => [newRequest, ...prev]);

    // Dispatch automatic student notification
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      userId: student.id,
      title: 'Outpass Submitted to HOD',
      message: `Your request ${newRequest.requestNumber} for ${newRequest.destination} was successfully registered and sent for departmental review.`,
      timestamp: 'Just now',
      read: false,
      type: 'INFO',
      relatedOutpassId: newRequest.id
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleProcessDecision = (
    outpassId: string,
    approved: boolean,
    remarks: string,
    staffName: string,
    staffRole: 'HOD' | 'WARDEN'
  ) => {
    setOutpasses(prev =>
      prev.map(op => {
        if (op.id !== outpassId) return op;

        const timestamp = new Date().toLocaleString('en-IN', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });

        const newStatus = approved ? 'APPROVED' : 'REJECTED';

        const updatedHistory = [
          ...op.approvalHistory,
          {
            id: `hist_${Date.now()}`,
            outpassId: op.id,
            staffName,
            staffRole,
            action: (approved ? 'APPROVED' : 'REJECTED') as 'APPROVED' | 'REJECTED',
            timestamp,
            remarks
          }
        ];

        return {
          ...op,
          status: newStatus,
          qrToken: approved ? `HITAM-GATEPASS-VALID-${op.collegeId}-${Date.now()}` : undefined,
          ...(staffRole === 'HOD'
            ? {
                hodApproval: {
                  approved,
                  staffName,
                  remarks,
                  timestamp
                }
              }
            : {
                wardenApproval: {
                  approved,
                  staffName,
                  remarks,
                  timestamp
                }
              }),
          approvalHistory: updatedHistory
        };
      })
    );

    // Find the affected outpass to generate student notification
    const targetOutpass = outpasses.find(o => o.id === outpassId);
    if (targetOutpass) {
      const decisionNotif: NotificationItem = {
        id: `notif_${Date.now()}`,
        userId: student.id,
        title: approved ? `Outpass Approved by ${staffName}` : `Outpass Rejected by ${staffName}`,
        message: `Decision on ${targetOutpass.requestNumber} (${targetOutpass.destination}): ${approved ? 'APPROVED' : 'REJECTED'}. Remarks: "${remarks}"`,
        timestamp: 'Just now',
        read: false,
        type: approved ? 'SUCCESS' : 'ALERT',
        relatedOutpassId: targetOutpass.id
      };
      setNotifications(prev => [decisionNotif, ...prev]);
    }
  };

  // Notification Handlers
  const handleMarkAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Role switching
  const handleRoleChange = (role: Role) => {
    setCurrentRole(role);
    if (role === 'HOD' || role === 'WARDEN') {
      setActiveStaffRole(role);
      setActiveTab('staff-approval');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleLoginSuccess = (role: Role, identifier: string) => {
    setIsLoggedIn(true);
    handleRoleChange(role);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setIsAuthModalOpen(true);
  };

  const pendingCount = outpasses.filter(o => o.status === 'PENDING').length;
  const unreadNotifCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50/80 via-emerald-100/30 to-green-50/50 text-gray-900 font-sans flex flex-col antialiased">
      
      {/* Top Header */}
      <Header
        currentRole={currentRole}
        onRoleChange={handleRoleChange}
        student={student}
        staff={staffMembers}
        unreadNotifCount={unreadNotifCount}
        onOpenNotifications={() => setActiveTab('notifications')}
        onOpenLogin={() => setIsAuthModalOpen(true)}
        onOpenGuide={() => setIsGuideModalOpen(true)}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Body Layout (Sidebar + Content) */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabSelect={(tab) => {
            setActiveTab(tab);
            if (tab === 'staff-approval' && currentRole === 'STUDENT') {
              setCurrentRole('HOD');
              setActiveStaffRole('HOD');
            }
          }}
          currentRole={currentRole}
          pendingCount={pendingCount}
          unreadCount={unreadNotifCount}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          onOpenGuide={() => setIsGuideModalOpen(true)}
        />

        {/* Dynamic Main Page Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
          
          {activeTab === 'dashboard' && (
            <StudentDashboard
              student={student}
              outpasses={outpasses}
              announcements={announcements}
              onNavigateToApply={() => setActiveTab('apply')}
              onNavigateToHistory={() => setActiveTab('history')}
              onNavigateToNotifications={() => setActiveTab('notifications')}
              onViewOutpass={(op) => {
                setActiveTab('history');
              }}
            />
          )}

          {activeTab === 'apply' && (
            <ApplyOutpassForm
              student={student}
              onSubmit={handleApplyOutpass}
              onCancel={() => setActiveTab('history')}
            />
          )}

          {activeTab === 'history' && (
            <OutpassHistory
              outpasses={outpasses}
              student={student}
              onNavigateToApply={() => setActiveTab('apply')}
            />
          )}

          {activeTab === 'staff-approval' && (
            <StaffApprovalView
              outpasses={outpasses}
              staffMembers={staffMembers}
              activeStaffRole={activeStaffRole}
              onSwitchStaffRole={(role) => setActiveStaffRole(role)}
              onProcessDecision={handleProcessDecision}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileView
              student={student}
              onUpdateProfile={(updated) => setStudent(prev => ({ ...prev, ...updated }))}
            />
          )}

          {activeTab === 'college' && (
            <CollegeAcademicView />
          )}

          {activeTab === 'academics' && (
            <CollegeAcademicView />
          )}

          {activeTab === 'notifications' && (
            <NotificationsView
              notifications={notifications}
              onMarkAsRead={handleMarkAsRead}
              onMarkAllAsRead={handleMarkAllAsRead}
              onSelectOutpassById={(id) => {
                setActiveTab('history');
              }}
            />
          )}

          {activeTab === 'java-code' && (
            <JavaCodeRepoView />
          )}

          {activeTab === 'syllabus-hub' && (
            <SyllabusHubView />
          )}

        </main>

      </div>

      {/* Dark Forest Green Footer */}
      <footer className="bg-emerald-950 text-emerald-200 border-t border-emerald-900 mt-auto py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
            
            <div className="flex items-center space-x-3 text-center md:text-left">
              <div className="w-9 h-9 rounded-lg bg-emerald-800 text-emerald-300 flex items-center justify-center font-bold">
                <Building2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="font-extrabold text-white text-sm">
                  Hyderabad Institute of Technology and Management (HITAM)
                </div>
                <div className="text-emerald-400 text-[11px]">
                  Autonomous Institution • Accredited by NAAC 'A+' & NBA • Affiliated to JNTUH
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 text-[11px] text-emerald-300/80">
              <span className="flex items-center gap-1">
                <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                India's First Green Campus
              </span>
              <span>•</span>
              <span>B.Tech - Artificial Intelligence & Machine Learning</span>
              <span>•</span>
              <button
                onClick={() => setIsGuideModalOpen(true)}
                className="text-amber-300 hover:underline font-bold"
              >
                Teacher Project Guide
              </button>
            </div>

          </div>

          <div className="mt-6 pt-4 border-t border-emerald-900/60 text-center text-[10px] text-emerald-400/60">
            © 2026 HITAM Smart Outpass Management System. Engineered for 2nd Year B.Tech Academic Curriculum.
          </div>
        </div>
      </footer>

      {/* Interactive Teacher Guide Modal */}
      <TeacherGuideModal
        isOpen={isGuideModalOpen}
        onClose={() => setIsGuideModalOpen(false)}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

    </div>
  );
}
