import React, { useState } from 'react';
import { 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  Calendar, 
  Clock, 
  MapPin, 
  Phone, 
  FileText, 
  Upload, 
  Info,
  ShieldCheck,
  User,
  X
} from 'lucide-react';
import { StudentProfile, OutpassReason, OutpassRequest } from '../types';

interface ApplyOutpassFormProps {
  student: StudentProfile;
  onSubmit: (newRequest: OutpassRequest) => void;
  onCancel: () => void;
}

export const ApplyOutpassForm: React.FC<ApplyOutpassFormProps> = ({
  student,
  onSubmit,
  onCancel
}) => {
  // Form State
  const [reason, setReason] = useState<OutpassReason>('Home Visit');
  const [destination, setDestination] = useState('');
  const [outpassDate, setOutpassDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [leavingTime, setLeavingTime] = useState('16:30');
  const [expectedReturnDate, setExpectedReturnDate] = useState(() => {
    const dayAfter = new Date();
    dayAfter.setDate(dayAfter.getDate() + 2);
    return dayAfter.toISOString().split('T')[0];
  });
  const [expectedReturnTime, setExpectedReturnTime] = useState('08:30');
  const [parentContact, setParentContact] = useState(student.parentPhone || '+91 94401 23456');
  const [additionalExplanation, setAdditionalExplanation] = useState('');
  const [docFile, setDocFile] = useState<File | null>(null);

  // Errors & Feedback State
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successData, setSuccessData] = useState<OutpassRequest | null>(null);

  const reasonsList: OutpassReason[] = [
    'Home Visit',
    'Medical Emergency',
    'Family Emergency',
    'Campus Placement / Internship',
    'Official College Work',
    'Personal Work',
    'Other'
  ];

  const validateForm = () => {
    const errs: Record<string, string> = {};

    if (!destination.trim()) {
      errs.destination = 'Destination is required.';
    } else if (destination.trim().length < 3) {
      errs.destination = 'Please provide a clear destination (at least 3 characters).';
    }

    if (!outpassDate) {
      errs.outpassDate = 'Outpass date is mandatory.';
    }

    if (!leavingTime) {
      errs.leavingTime = 'Leaving time is mandatory.';
    }

    if (!expectedReturnDate) {
      errs.expectedReturnDate = 'Expected return date is mandatory.';
    }

    if (!expectedReturnTime) {
      errs.expectedReturnTime = 'Expected return time is mandatory.';
    }

    // Time chronology check: Return date/time must be strictly after departure
    if (outpassDate && leavingTime && expectedReturnDate && expectedReturnTime) {
      const departureDateTime = new Date(`${outpassDate}T${leavingTime}`);
      const returnDateTime = new Date(`${expectedReturnDate}T${expectedReturnTime}`);

      if (isNaN(departureDateTime.getTime()) || isNaN(returnDateTime.getTime())) {
        errs.expectedReturnDate = 'Invalid date or time format.';
      } else if (returnDateTime <= departureDateTime) {
        errs.expectedReturnDate = 'Expected return date & time must be strictly AFTER departure time!';
      }
    }

    if (!parentContact.trim()) {
      errs.parentContact = 'Parent/guardian phone number is mandatory for outpass verification.';
    } else if (!/^(\+91[\s-]?)?[6-9]\d{9}$/.test(parentContact.replace(/[\s-]/g, ''))) {
      errs.parentContact = 'Please enter a valid 10-digit mobile number.';
    }

    if (!additionalExplanation.trim()) {
      errs.additionalExplanation = 'Please provide a brief explanation or reason detail for the HOD.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    // Simulate backend Spring Boot REST call processing delay
    setTimeout(() => {
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const newRequestNumber = `HITAM-OP-2026-${randomSuffix}`;

      const newOutpass: OutpassRequest = {
        id: `op_${Date.now()}`,
        requestNumber: newRequestNumber,
        studentId: student.id,
        studentName: student.name,
        collegeId: student.collegeId,
        department: student.department,
        academicYear: student.academicYear,
        semester: student.semester,
        reason,
        destination: destination.trim(),
        outpassDate,
        leavingTime,
        expectedReturnDate,
        expectedReturnTime,
        parentContact: parentContact.trim(),
        additionalExplanation: additionalExplanation.trim(),
        supportingDocName: docFile ? docFile.name : undefined,
        status: 'PENDING', // NEVER automatically approved as instructed
        submissionDate: new Date().toLocaleString('en-IN', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        approvalHistory: []
      };

      setIsSubmitting(false);
      setSuccessData(newOutpass);
      onSubmit(newOutpass);
    }, 700);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn pb-12">
      
      {/* Header Card */}
      <div className="bg-gradient-to-r from-emerald-900 to-green-950 text-white p-6 rounded-2xl shadow-lg border border-emerald-700/50">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-700/60 flex items-center justify-center text-emerald-300">
            <Send className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">Apply for Student Outpass</h2>
            <p className="text-xs text-emerald-200/90 mt-0.5">
              Submit request for residential campus leave clearance. Requests undergo HOD review & Chief Warden approval.
            </p>
          </div>
        </div>
      </div>

      {/* Success Notification Modal */}
      {successData && (
        <div className="bg-emerald-50 border-2 border-emerald-500 rounded-2xl p-6 shadow-xl space-y-4 animate-scaleUp">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-emerald-950">
                  Outpass Request Submitted Successfully!
                </h3>
                <p className="text-xs text-emerald-800">
                  Your outpass application has been assigned request ID{' '}
                  <span className="font-mono font-bold text-emerald-950 bg-emerald-200/60 px-2 py-0.5 rounded">
                    {successData.requestNumber}
                  </span>{' '}
                  and routed to HOD Desk.
                </p>
              </div>
            </div>
            <button
              onClick={onCancel}
              className="text-gray-400 hover:text-gray-600 p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="bg-white rounded-xl p-4 border border-emerald-200 text-xs text-gray-700 space-y-2">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <span className="text-gray-500 block">Status:</span>
                <span className="font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full inline-block mt-0.5">
                  PENDING REVIEW
                </span>
              </div>
              <div>
                <span className="text-gray-500 block">Destination:</span>
                <span className="font-semibold text-gray-900">{successData.destination}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Departure:</span>
                <span className="font-semibold text-gray-900">{successData.outpassDate} at {successData.leavingTime}</span>
              </div>
              <div>
                <span className="text-gray-500 block">Expected Return:</span>
                <span className="font-semibold text-gray-900">{successData.expectedReturnDate} at {successData.expectedReturnTime}</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-2">
            <button
              onClick={onCancel}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow"
            >
              Go to Outpass History
            </button>
          </div>
        </div>
      )}

      {/* Main Form Body */}
      {!successData && (
        <form onSubmit={handleSubmit} className="bg-white/95 backdrop-blur-md rounded-2xl shadow-md border border-emerald-100 p-6 sm:p-8 space-y-6">
          
          {/* Section 1: Pre-filled Student Details (Read-only for security) */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-950 pb-2 border-b border-gray-100">
              <User className="w-4 h-4 text-emerald-700" />
              <span>Student Academic Profile (Auto-Verified)</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-emerald-50/50 p-4 rounded-xl border border-emerald-100/70 text-xs">
              <div>
                <label className="text-gray-500 font-medium">Student Name</label>
                <div className="font-bold text-gray-900 mt-0.5">{student.name}</div>
              </div>
              <div>
                <label className="text-gray-500 font-medium">College ID (Roll No)</label>
                <div className="font-mono font-bold text-emerald-900 mt-0.5">{student.collegeId}</div>
              </div>
              <div>
                <label className="text-gray-500 font-medium">Department & Program</label>
                <div className="font-bold text-gray-900 mt-0.5">{student.program}</div>
              </div>
              <div>
                <label className="text-gray-500 font-medium">Current Semester</label>
                <div className="font-bold text-gray-900 mt-0.5">{student.academicYear} • {student.semester}</div>
              </div>
            </div>
          </div>

          {/* Section 2: Outpass Journey Details */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-950 pb-2 border-b border-gray-100">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>Outpass Particulars</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Reason Dropdown */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Reason for Outpass <span className="text-red-500">*</span>
                </label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value as OutpassReason)}
                  className="w-full text-xs font-medium px-3 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-200 outline-none bg-white transition-all"
                >
                  {reasonsList.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              {/* Destination */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  Destination Address / City <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Secunderabad (Home) or T-Hub 2.0 Madhapur"
                  value={destination}
                  onChange={(e) => {
                    setDestination(e.target.value);
                    if (errors.destination) setErrors({ ...errors, destination: '' });
                  }}
                  className={`w-full text-xs px-3 py-2.5 rounded-xl border ${
                    errors.destination ? 'border-red-500 bg-red-50/30' : 'border-gray-200'
                  } focus:border-emerald-600 focus:ring-2 focus:ring-emerald-200 outline-none transition-all`}
                />
                {errors.destination && (
                  <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors.destination}
                  </p>
                )}
              </div>

            </div>

            {/* Departure & Return Timings Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-xl bg-gray-50/60 border border-gray-200/80">
              
              {/* Leaving Date */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  Leaving Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={outpassDate}
                  onChange={(e) => {
                    setOutpassDate(e.target.value);
                    if (errors.outpassDate) setErrors({ ...errors, outpassDate: '' });
                  }}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 focus:border-emerald-600 outline-none bg-white"
                />
              </div>

              {/* Leaving Time */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-emerald-700" />
                  Leaving Time <span className="text-red-500">*</span>
                </label>
                <input
                  type="time"
                  value={leavingTime}
                  onChange={(e) => {
                    setLeavingTime(e.target.value);
                    if (errors.leavingTime) setErrors({ ...errors, leavingTime: '' });
                  }}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 focus:border-emerald-600 outline-none bg-white"
                />
              </div>

              {/* Expected Return Date */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                  Return Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={expectedReturnDate}
                  onChange={(e) => {
                    setExpectedReturnDate(e.target.value);
                    if (errors.expectedReturnDate) setErrors({ ...errors, expectedReturnDate: '' });
                  }}
                  className={`w-full text-xs px-3 py-2 rounded-lg border ${
                    errors.expectedReturnDate ? 'border-red-500 bg-red-50/50' : 'border-gray-200'
                  } focus:border-emerald-600 outline-none bg-white`}
                />
              </div>

              {/* Expected Return Time */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-emerald-700" />
                  Return Time <span className="text-red-500">*</span>
                </label>
                <input
                  type="time"
                  value={expectedReturnTime}
                  onChange={(e) => {
                    setExpectedReturnTime(e.target.value);
                    if (errors.expectedReturnTime) setErrors({ ...errors, expectedReturnTime: '' });
                  }}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 focus:border-emerald-600 outline-none bg-white"
                />
              </div>

            </div>

            {errors.expectedReturnDate && (
              <p className="text-xs text-red-600 font-semibold bg-red-50 p-2.5 rounded-lg border border-red-200 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {errors.expectedReturnDate}
              </p>
            )}

            {/* Parent Contact */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-emerald-700" />
                Parent / Guardian Contact Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                placeholder="+91 94401 23456"
                value={parentContact}
                onChange={(e) => {
                  setParentContact(e.target.value);
                  if (errors.parentContact) setErrors({ ...errors, parentContact: '' });
                }}
                className={`w-full text-xs px-3 py-2.5 rounded-xl border ${
                  errors.parentContact ? 'border-red-500 bg-red-50/30' : 'border-gray-200'
                } focus:border-emerald-600 focus:ring-2 focus:ring-emerald-200 outline-none`}
              />
              <span className="text-[11px] text-gray-400 mt-1 block">
                Wardens verify residential leaves with parents for hostel safety compliance.
              </span>
              {errors.parentContact && (
                <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {errors.parentContact}
                </p>
              )}
            </div>

            {/* Detailed Explanation */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-emerald-700" />
                Detailed Purpose & Explanation <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={3}
                placeholder="Describe your travel purpose, reason for leaving early/late, emergency details, or family gathering details..."
                value={additionalExplanation}
                onChange={(e) => {
                  setAdditionalExplanation(e.target.value);
                  if (errors.additionalExplanation) setErrors({ ...errors, additionalExplanation: '' });
                }}
                className={`w-full text-xs p-3 rounded-xl border ${
                  errors.additionalExplanation ? 'border-red-500 bg-red-50/30' : 'border-gray-200'
                } focus:border-emerald-600 focus:ring-2 focus:ring-emerald-200 outline-none`}
              />
              {errors.additionalExplanation && (
                <p className="text-[11px] text-red-500 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {errors.additionalExplanation}
                </p>
              )}
            </div>

            {/* Optional Supporting Document Upload */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                <Upload className="w-3.5 h-3.5 text-emerald-700" />
                Supporting Document (Optional: Medical slip, Hackathon letter, Parent letter)
              </label>
              <div className="border border-dashed border-gray-300 rounded-xl p-4 text-center hover:bg-gray-50 transition-colors">
                <input
                  type="file"
                  id="doc-upload"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setDocFile(e.target.files[0]);
                    }
                  }}
                  accept=".pdf,.png,.jpg,.jpeg"
                />
                <label htmlFor="doc-upload" className="cursor-pointer block">
                  <Upload className="w-6 h-6 text-emerald-600 mx-auto mb-1.5" />
                  <span className="text-xs font-bold text-emerald-800">
                    {docFile ? docFile.name : 'Click to select PDF or image file (max 5MB)'}
                  </span>
                  <span className="text-[10px] text-gray-400 block mt-0.5">
                    {docFile ? `${(docFile.size / 1024).toFixed(1)} KB selected` : 'Supported: PDF, JPG, PNG'}
                  </span>
                </label>
                {docFile && (
                  <button
                    type="button"
                    onClick={() => setDocFile(null)}
                    className="mt-2 text-[11px] text-red-600 hover:underline font-semibold"
                  >
                    Remove attachment
                  </button>
                )}
              </div>
            </div>

          </div>

          {/* Institutional Compliance Notice */}
          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-800 flex items-start space-x-2">
            <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <strong>HITAM Outpass Security Notice:</strong> Submitting this request logs an official entry in the college database. As mandated by institutional safety guidelines, the request will be initially marked <strong>Pending</strong>. You may not exit the campus gates until clearance is certified by both the HOD and Hostel Warden.
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t border-gray-100">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2.5 rounded-xl border border-gray-300 text-gray-700 text-xs font-semibold hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-xs shadow-md hover:shadow-lg disabled:opacity-60 transition-all flex items-center space-x-2 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Submitting to HOD...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submit Outpass Request</span>
                </>
              )}
            </button>
          </div>

        </form>
      )}

    </div>
  );
};
