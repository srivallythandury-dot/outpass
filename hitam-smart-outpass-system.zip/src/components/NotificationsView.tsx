import React from 'react';
import { 
  Bell, 
  CheckCircle2, 
  AlertCircle, 
  Info, 
  AlertTriangle, 
  Check, 
  Trash2,
  ExternalLink
} from 'lucide-react';
import { NotificationItem, OutpassRequest } from '../types';

interface NotificationsViewProps {
  notifications: NotificationItem[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onSelectOutpassById?: (outpassId: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onSelectOutpassById
}) => {
  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'SUCCESS':
        return <CheckCircle2 className="w-5 h-5 text-emerald-600" />;
      case 'ALERT':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'WARNING':
        return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'INFO':
      default:
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn pb-12">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-green-950 text-white p-6 rounded-2xl shadow-xl border border-emerald-700/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-700/60 flex items-center justify-center text-emerald-300">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">System Notifications</h2>
            <p className="text-xs text-emerald-200/90 mt-0.5">
              Updates on outpass requests, HOD clearances, and college administrative circulars.
            </p>
          </div>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={onMarkAllAsRead}
            className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-lg flex items-center space-x-1.5 shadow transition-colors self-start sm:self-center"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Mark All as Read</span>
          </button>
        )}
      </div>

      {/* Notifications List */}
      {notifications.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-dashed border-gray-300 shadow-sm">
          <Bell className="w-12 h-12 text-gray-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-gray-700">No notifications yet</h3>
          <p className="text-xs text-gray-400 mt-1">
            You're all caught up! New updates on your outpass decisions will appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-4 ${
                notif.read
                  ? 'bg-white border-gray-100 text-gray-700'
                  : 'bg-emerald-50/60 border-emerald-200 shadow-xs'
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className="mt-0.5 shrink-0">{getIcon(notif.type)}</div>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h4 className={`text-xs font-bold ${notif.read ? 'text-gray-900' : 'text-emerald-950 font-black'}`}>
                      {notif.title}
                    </h4>
                    {!notif.read && (
                      <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                    )}
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed">{notif.message}</p>
                  <div className="text-[10px] text-gray-400 font-medium">{notif.timestamp}</div>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                {!notif.read && (
                  <button
                    onClick={() => onMarkAsRead(notif.id)}
                    className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 p-1"
                    title="Mark as read"
                  >
                    Mark read
                  </button>
                )}
                {notif.relatedOutpassId && onSelectOutpassById && (
                  <button
                    onClick={() => onSelectOutpassById(notif.relatedOutpassId!)}
                    className="p-1 text-emerald-700 hover:text-emerald-900 rounded"
                    title="View Outpass"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
