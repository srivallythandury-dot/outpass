import React, { useState } from 'react';
import { 
  Building2, 
  Lock, 
  User, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  CheckCircle2, 
  X,
  Sparkles,
  GraduationCap,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { Role } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (role: Role, identifier: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess
}) => {
  const [selectedRole, setSelectedRole] = useState<Role>('STUDENT');
  const [collegeId, setCollegeId] = useState('23M41A6601');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleRoleTabChange = (role: Role) => {
    setSelectedRole(role);
    setErrorMsg('');
    if (role === 'STUDENT') {
      setCollegeId('23M41A6601');
      setPassword('password123');
    } else if (role === 'HOD') {
      setCollegeId('HOD-AIML');
      setPassword('password123');
    } else {
      setCollegeId('WARDEN-01');
      setPassword('password123');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!collegeId.trim()) {
      setErrorMsg('Please enter your College ID or Employee Staff ID.');
      return;
    }

    if (!password.trim()) {
      setErrorMsg('Password is required.');
      return;
    }

    setIsLoading(true);

    // Simulate Spring Boot /api/auth/login with BCrypt validation
    setTimeout(() => {
      setIsLoading(false);

      if (password === 'password123') {
        onLoginSuccess(selectedRole, collegeId.trim());
        onClose();
      } else {
        setErrorMsg('Invalid credentials! Default demo password is "password123".');
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-emerald-200 overflow-hidden animate-scaleUp">
        
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-green-950 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-emerald-300 hover:text-white p-1"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-700/80 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                HITAM Smart Outpass Portal
              </h3>
              <p className="text-[11px] text-emerald-200">
                Autonomous Institution • Single Sign-On Demo
              </p>
            </div>
          </div>

          {/* Role Selection Tabs */}
          <div className="mt-4 grid grid-cols-3 gap-1 bg-emerald-900/80 p-1 rounded-xl border border-emerald-700/50 text-[11px] font-bold">
            <button
              type="button"
              onClick={() => handleRoleTabChange('STUDENT')}
              className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
                selectedRole === 'STUDENT' ? 'bg-emerald-500 text-emerald-950 shadow' : 'text-emerald-200 hover:text-white'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Student</span>
            </button>

            <button
              type="button"
              onClick={() => handleRoleTabChange('HOD')}
              className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
                selectedRole === 'HOD' ? 'bg-amber-400 text-emerald-950 shadow' : 'text-emerald-200 hover:text-white'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>HOD Desk</span>
            </button>

            <button
              type="button"
              onClick={() => handleRoleTabChange('WARDEN')}
              className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
                selectedRole === 'WARDEN' ? 'bg-emerald-400 text-emerald-950 shadow' : 'text-emerald-200 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Warden</span>
            </button>
          </div>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-red-50 rounded-xl border border-red-200 text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-emerald-700" />
              {selectedRole === 'STUDENT' ? 'College ID (Roll Number)' : 'Staff Employee ID'}
            </label>
            <input
              type="text"
              value={collegeId}
              onChange={(e) => setCollegeId(e.target.value)}
              placeholder={selectedRole === 'STUDENT' ? 'e.g. 23M41A6601' : 'e.g. HOD-AIML'}
              className="w-full text-xs font-mono px-3.5 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-emerald-700" />
              Portal Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-400 outline-none pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className="mt-1 flex items-center justify-between text-[11px] text-gray-400">
              <span>Demo password: <strong className="text-emerald-700 font-mono">password123</strong></span>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <span>Sign In to {selectedRole === 'STUDENT' ? 'Student Portal' : selectedRole === 'HOD' ? 'HOD Desk' : 'Warden Desk'}</span>
              )}
            </button>
          </div>

          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-[11px] text-emerald-800 text-center">
            <strong>Security Architecture:</strong> Uses Spring Security 6 with BCrypt hashing. Never inputs real institutional ERP passwords.
          </div>
        </form>

      </div>
    </div>
  );
};
