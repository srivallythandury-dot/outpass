import React from 'react';
import { 
  LayoutDashboard, 
  Send, 
  History, 
  User, 
  Building, 
  GraduationCap, 
  Bell, 
  Code2, 
  BookMarked, 
  CheckSquare, 
  ShieldAlert,
  Sparkles,
  HelpCircle,
  FileCode,
  Leaf
} from 'lucide-react';
import { Role } from '../types';

export type NavTab = 
  | 'dashboard'
  | 'apply'
  | 'history'
  | 'profile'
  | 'college'
  | 'academics'
  | 'notifications'
  | 'staff-approval'
  | 'java-code'
  | 'syllabus-hub';

interface SidebarProps {
  activeTab: NavTab;
  onTabSelect: (tab: NavTab) => void;
  currentRole: Role;
  pendingCount: number;
  unreadCount: number;
  isOpen: boolean;
  onClose: () => void;
  onOpenGuide: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabSelect,
  currentRole,
  pendingCount,
  unreadCount,
  isOpen,
  onClose,
  onOpenGuide
}) => {
  const studentNavItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'apply', label: 'Apply for Outpass', icon: <Send className="w-4 h-4 text-emerald-400" /> },
    { id: 'history', label: 'Outpass History', icon: <History className="w-4 h-4" />, badge: pendingCount > 0 ? pendingCount : undefined },
    { id: 'profile', label: 'My Profile', icon: <User className="w-4 h-4" /> },
    { id: 'college', label: 'College Details', icon: <Building className="w-4 h-4" /> },
    { id: 'academics', label: 'Academic Details', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" />, badge: unreadCount > 0 ? unreadCount : undefined },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-emerald-950/70 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:sticky top-20 left-0 h-[calc(100vh-5rem)] w-64 bg-emerald-950 text-emerald-100 flex flex-col z-40 border-r border-emerald-800/60 shadow-xl transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-6">

          {/* Student Portal Navigation */}
          <div>
            <div className="px-3 mb-2 text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center justify-between">
              <span>Student Services</span>
              <Leaf className="w-3 h-3 text-emerald-500" />
            </div>
            <nav className="space-y-1">
              {studentNavItems.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onTabSelect(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-md font-semibold'
                        : 'text-emerald-200 hover:bg-emerald-900/70 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className={isActive ? 'text-white' : 'text-emerald-400'}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>
                    {item.badge !== undefined && (
                      <span className="bg-amber-400 text-emerald-950 text-[10px] font-extrabold px-1.5 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Staff Decision Workflow */}
          <div>
            <div className="px-3 mb-2 text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center justify-between">
              <span>Authority Approvals</span>
              <ShieldAlert className="w-3 h-3 text-amber-400" />
            </div>
            <button
              onClick={() => {
                onTabSelect('staff-approval');
                onClose();
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'staff-approval'
                  ? 'bg-amber-500 text-emerald-950 font-bold shadow-md'
                  : 'text-amber-200/90 hover:bg-emerald-900/70 hover:text-amber-100'
              }`}
            >
              <div className="flex items-center space-x-3">
                <CheckSquare className="w-4 h-4 text-amber-400" />
                <span>HOD & Warden Desk</span>
              </div>
              {pendingCount > 0 && (
                <span className="bg-red-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full animate-bounce">
                  {pendingCount}
                </span>
              )}
            </button>
          </div>

          {/* Academic 5th Module & Java Source Code Labs */}
          <div>
            <div className="px-3 mb-2 text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center justify-between">
              <span>2nd Year B.Tech Labs</span>
              <Sparkles className="w-3 h-3 text-emerald-300" />
            </div>
            <div className="space-y-1">
              <button
                onClick={() => {
                  onTabSelect('java-code');
                  onClose();
                }}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'java-code'
                    ? 'bg-emerald-700 text-white font-semibold shadow-md'
                    : 'text-emerald-200 hover:bg-emerald-900/70 hover:text-white'
                }`}
              >
                <Code2 className="w-4 h-4 text-emerald-400" />
                <span>Spring Boot 3 Codebase</span>
              </button>

              <button
                onClick={() => {
                  onTabSelect('syllabus-hub');
                  onClose();
                }}
                className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'syllabus-hub'
                    ? 'bg-emerald-700 text-white font-semibold shadow-md'
                    : 'text-emerald-200 hover:bg-emerald-900/70 hover:text-white'
                }`}
              >
                <BookMarked className="w-4 h-4 text-amber-300" />
                <span>Java 5th Module Hub</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Student Help & Teacher Guide Card */}
        <div className="p-3 bg-emerald-900/40 border-t border-emerald-800/60">
          <button
            onClick={onOpenGuide}
            className="w-full flex items-center justify-center space-x-2 px-3 py-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white rounded-lg text-xs font-bold shadow-md transition-all"
          >
            <HelpCircle className="w-4 h-4 text-emerald-200" />
            <span>Beginner Guide (Step-by-Step)</span>
          </button>
          <div className="mt-2 text-center text-[10px] text-emerald-300/70">
            HITAM • JNTUH Autonomous Affiliation
          </div>
        </div>
      </aside>
    </>
  );
};
