import React from 'react';
import { 
  GraduationCap, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Clock3, 
  FileText, 
  TrendingUp, 
  Award, 
  BookOpen, 
  ExternalLink, 
  ChevronRight,
  ShieldCheck,
  Send,
  Sparkles,
  MapPin,
  Building2,
  BellRing
} from 'lucide-react';
import { StudentProfile, OutpassRequest, CollegeAnnouncement } from '../types';

interface StudentDashboardProps {
  student: StudentProfile;
  outpasses: OutpassRequest[];
  announcements: CollegeAnnouncement[];
  onNavigateToApply: () => void;
  onNavigateToHistory: () => void;
  onNavigateToNotifications: () => void;
  onViewOutpass: (outpass: OutpassRequest) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  student,
  outpasses,
  announcements,
  onNavigateToApply,
  onNavigateToHistory,
  onNavigateToNotifications,
  onViewOutpass
}) => {
  const totalRequests = outpasses.length;
  const pendingRequests = outpasses.filter(o => o.status === 'PENDING').length;
  const approvedRequests = outpasses.filter(o => o.status === 'APPROVED').length;
  const rejectedRequests = outpasses.filter(o => o.status === 'REJECTED').length;

  const recentOutpasses = outpasses.slice(0, 3);

  return (
    <div className="space-y-6 animate-fadeIn">

      {/* Hero Welcome Banner with Campus Green Theme */}
      <div className="relative rounded-2xl overflow-hidden shadow-xl border border-emerald-600/30 bg-gradient-to-br from-emerald-900 via-emerald-800 to-green-950 text-white p-6 sm:p-8">
        
        {/* Subtle Decorative Foliage Pattern Background */}
        <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-700/60 border border-emerald-500/40 text-emerald-200 text-xs font-semibold backdrop-blur-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>HITAM Autonomous Green Campus • Student Portal</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Welcome back, {student.name}!
            </h2>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-emerald-200/90 font-medium">
              <span className="flex items-center gap-1">
                <GraduationCap className="w-3.5 h-3.5 text-emerald-300" />
                ID: <strong className="text-white font-mono">{student.collegeId}</strong>
              </span>
              <span>•</span>
              <span>Program: <strong className="text-white">{student.program}</strong></span>
              <span>•</span>
              <span>Year: <strong className="text-white">{student.academicYear}</strong> ({student.semester})</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-300" />
                {student.hostelBlock}
              </span>
            </div>
          </div>

          {/* Quick Apply Action Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={onNavigateToApply}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-400 to-green-500 hover:from-emerald-300 hover:to-green-400 text-emerald-950 font-extrabold text-sm shadow-lg hover:shadow-xl hover:scale-102 transition-all flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Apply for Outpass</span>
            </button>
            <button
              onClick={onNavigateToHistory}
              className="px-4 py-3 rounded-xl bg-emerald-800/80 hover:bg-emerald-700 border border-emerald-500/40 text-white font-semibold text-sm transition-colors flex items-center justify-center space-x-1.5"
            >
              <Clock className="w-4 h-4 text-emerald-300" />
              <span>View History</span>
            </button>
          </div>
        </div>
      </div>

      {/* Academic Highlights & Key Performance Indicators (Mint Translucent Cards) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-700" />
            Academic Progress & Eligibility
          </h3>
          <span className="text-xs text-emerald-700 font-semibold">Semester IV Active</span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Attendance Card */}
          <div className="bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-sm border border-emerald-100 hover:border-emerald-300 transition-all hover:shadow-md">
            <div className="flex items-center justify-between text-emerald-700 mb-1">
              <span className="text-xs font-semibold">Overall Attendance</span>
              <TrendingUp className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black text-emerald-950">{student.attendancePercentage}%</span>
              <span className="text-[11px] text-emerald-600 font-bold">Eligible</span>
            </div>
            <div className="w-full bg-emerald-100 h-1.5 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-emerald-600 h-full rounded-full" 
                style={{ width: `${student.attendancePercentage}%` }}
              />
            </div>
            <p className="text-[10px] text-gray-500 mt-1.5">Req: Minimum 75% for outpass approval</p>
          </div>

          {/* Current CGPA */}
          <div className="bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-sm border border-emerald-100 hover:border-emerald-300 transition-all hover:shadow-md">
            <div className="flex items-center justify-between text-emerald-700 mb-1">
              <span className="text-xs font-semibold">Cumulative CGPA</span>
              <Award className="w-4 h-4 text-amber-500" />
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black text-emerald-950">{student.cgpa}</span>
              <span className="text-[11px] text-gray-500 font-medium">/ 10.0</span>
            </div>
            <div className="w-full bg-emerald-100 h-1.5 rounded-full mt-2 overflow-hidden">
              <div 
                className="bg-amber-500 h-full rounded-full" 
                style={{ width: `${(student.cgpa / 10) * 100}%` }}
              />
            </div>
            <p className="text-[10px] text-gray-500 mt-1.5">First Class with Distinction</p>
          </div>

          {/* Backlogs Count */}
          <div className="bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-sm border border-emerald-100 hover:border-emerald-300 transition-all hover:shadow-md">
            <div className="flex items-center justify-between text-emerald-700 mb-1">
              <span className="text-xs font-semibold">Active Backlogs</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black text-emerald-950">{student.backlogs}</span>
              <span className="text-[11px] text-emerald-600 font-bold">Clear Record</span>
            </div>
            <div className="w-full bg-emerald-100 h-1.5 rounded-full mt-2">
              <div className="bg-emerald-500 h-full rounded-full w-full" />
            </div>
            <p className="text-[10px] text-gray-500 mt-1.5">All Sem I, II & III papers cleared</p>
          </div>

          {/* Current Semester Credits */}
          <div className="bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-sm border border-emerald-100 hover:border-emerald-300 transition-all hover:shadow-md">
            <div className="flex items-center justify-between text-emerald-700 mb-1">
              <span className="text-xs font-semibold">Semester Credits</span>
              <BookOpen className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black text-emerald-950">{student.currentCredits}</span>
              <span className="text-[11px] text-gray-500 font-medium">Registered</span>
            </div>
            <div className="w-full bg-emerald-100 h-1.5 rounded-full mt-2">
              <div className="bg-emerald-600 h-full rounded-full w-full" />
            </div>
            <p className="text-[10px] text-gray-500 mt-1.5">Includes Java Lab & Algorithms Lab</p>
          </div>

        </div>
      </div>

      {/* Outpass Status Counters (4 Cards) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-700" />
            Outpass Request Status Overview
          </h3>
          <button 
            onClick={onNavigateToHistory}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          
          <div className="bg-white/95 rounded-xl p-4 border border-emerald-100 shadow-sm flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <div className="text-xl font-black text-gray-900">{totalRequests}</div>
              <div className="text-[11px] font-medium text-gray-500">Total Applied</div>
            </div>
          </div>

          <div className="bg-white/95 rounded-xl p-4 border border-amber-200 bg-amber-50/40 shadow-sm flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
              <Clock3 className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <div className="text-xl font-black text-amber-900">{pendingRequests}</div>
              <div className="text-[11px] font-medium text-amber-700">Pending Review</div>
            </div>
          </div>

          <div className="bg-white/95 rounded-xl p-4 border border-emerald-200 bg-emerald-50/50 shadow-sm flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-200 text-emerald-900 flex items-center justify-center font-bold">
              <CheckCircle2 className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <div className="text-xl font-black text-emerald-900">{approvedRequests}</div>
              <div className="text-[11px] font-medium text-emerald-700">Approved Passes</div>
            </div>
          </div>

          <div className="bg-white/95 rounded-xl p-4 border border-red-200 bg-red-50/40 shadow-sm flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 text-red-800 flex items-center justify-center font-bold">
              <AlertCircle className="w-5 h-5 text-red-700" />
            </div>
            <div>
              <div className="text-xl font-black text-red-900">{rejectedRequests}</div>
              <div className="text-[11px] font-medium text-red-700">Rejected</div>
            </div>
          </div>

        </div>
      </div>

      {/* Two Column Grid: Recent Outpasses & College Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Recent Activity Outpasses */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-700" />
              Recent Outpass Activity
            </h3>
            <span className="text-xs text-gray-500">Live Status Tracker</span>
          </div>

          {recentOutpasses.length === 0 ? (
            <div className="bg-white/90 rounded-xl p-8 text-center border border-dashed border-emerald-200">
              <p className="text-sm text-gray-500">No outpass requests submitted yet.</p>
              <button
                onClick={onNavigateToApply}
                className="mt-3 px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold"
              >
                Create your first request
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {recentOutpasses.map((op) => (
                <div
                  key={op.id}
                  onClick={() => onViewOutpass(op)}
                  className="bg-white/95 hover:bg-white rounded-xl p-4 border border-emerald-100 hover:border-emerald-300 shadow-sm hover:shadow-md transition-all cursor-pointer group"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center space-x-3">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-xs ${
                        op.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                        op.status === 'PENDING' ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                        'bg-red-100 text-red-800 border border-red-300'
                      }`}>
                        {op.status === 'APPROVED' ? 'OK' : op.status === 'PENDING' ? 'REV' : 'REJ'}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-mono font-bold text-emerald-950">
                            {op.requestNumber}
                          </span>
                          <span className="text-xs font-semibold text-gray-700">
                            • {op.reason}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 line-clamp-1">
                          Destination: <span className="text-gray-800 font-medium">{op.destination}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 self-end sm:self-center">
                      <div className="text-right">
                        <div className="text-[11px] font-semibold text-gray-700">
                          {op.outpassDate} ({op.leavingTime})
                        </div>
                        <div className="text-[10px] text-gray-500">
                          Return: {op.expectedReturnDate} ({op.expectedReturnTime})
                        </div>
                      </div>

                      <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                        op.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-800' :
                        op.status === 'PENDING' ? 'bg-amber-100 text-amber-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {op.status}
                      </span>
                    </div>
                  </div>

                  {/* Show remark preview if available */}
                  {(op.hodApproval?.remarks || op.wardenApproval?.remarks) && (
                    <div className="mt-2.5 pt-2 border-t border-gray-100 text-[11px] text-gray-600 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="italic line-clamp-1">
                        Remarks: {op.wardenApproval?.remarks || op.hodApproval?.remarks}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right 1 Col: Important College Announcements & Quick Links */}
        <div className="space-y-4">
          
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
              <BellRing className="w-4 h-4 text-emerald-700" />
              HITAM Circulars
            </h3>
            <span className="text-xs text-emerald-700 font-semibold">Official Notices</span>
          </div>

          <div className="bg-white/95 rounded-xl p-4 border border-emerald-100 shadow-sm space-y-3">
            {announcements.map((ann) => (
              <div 
                key={ann.id}
                className="p-3 rounded-lg bg-emerald-50/50 hover:bg-emerald-50 border border-emerald-100/80 transition-colors"
              >
                <div className="flex items-center justify-between text-[11px] mb-1">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    ann.important ? 'bg-red-100 text-red-700' : 'bg-emerald-200/70 text-emerald-800'
                  }`}>
                    {ann.category}
                  </span>
                  <span className="text-gray-400">{ann.date}</span>
                </div>
                <h4 className="text-xs font-bold text-gray-900 line-clamp-1">{ann.title}</h4>
                <p className="text-[11px] text-gray-600 mt-1 line-clamp-2 leading-relaxed">{ann.content}</p>
              </div>
            ))}
          </div>

          {/* Useful College Quick Links */}
          <div className="bg-emerald-950 text-white rounded-xl p-4 shadow-md border border-emerald-800/60">
            <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-emerald-300 mb-3">
              <Building2 className="w-4 h-4" />
              <span>Campus Portals & Resources</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <a
                href="#cms"
                onClick={(e) => { e.preventDefault(); alert("HITAM CMS Portal link simulation"); }}
                className="p-2 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 flex items-center justify-between text-emerald-200 hover:text-white transition-colors"
              >
                <span>HITAM CMS</span>
                <ExternalLink className="w-3 h-3 text-emerald-400" />
              </a>
              <a
                href="#jntuh"
                onClick={(e) => { e.preventDefault(); alert("JNTUH University Portal link simulation"); }}
                className="p-2 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 flex items-center justify-between text-emerald-200 hover:text-white transition-colors"
              >
                <span>JNTUH Results</span>
                <ExternalLink className="w-3 h-3 text-emerald-400" />
              </a>
              <a
                href="#library"
                onClick={(e) => { e.preventDefault(); alert("Digital Library Catalogue simulation"); }}
                className="p-2 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 flex items-center justify-between text-emerald-200 hover:text-white transition-colors"
              >
                <span>Digital Library</span>
                <ExternalLink className="w-3 h-3 text-emerald-400" />
              </a>
              <a
                href="#transport"
                onClick={(e) => { e.preventDefault(); alert("College Bus Routes & Schedule simulation"); }}
                className="p-2 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 flex items-center justify-between text-emerald-200 hover:text-white transition-colors"
              >
                <span>Bus Routes</span>
                <ExternalLink className="w-3 h-3 text-emerald-400" />
              </a>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
