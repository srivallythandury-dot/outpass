import React, { useState } from 'react';
import { 
  BookMarked, 
  Layers, 
  Database, 
  Server, 
  Code, 
  HelpCircle, 
  Copy, 
  Check, 
  Play, 
  Layout, 
  Grid, 
  Columns, 
  Maximize2,
  ChevronRight,
  Sparkles,
  Award
} from 'lucide-react';
import { SYLLABUS_MODULES, SyllabusTopic } from '../data/syllabus5thModule';

export const SyllabusHubView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'awt' | 'jdbc' | 'servlets' | 'jsp' | 'exam-bank'>('awt');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // AWT Interactive Layout Simulator State
  const [selectedLayout, setSelectedLayout] = useState<'FlowLayout' | 'BorderLayout' | 'GridLayout' | 'CardLayout'>('BorderLayout');
  const [activeCardIndex, setActiveCardIndex] = useState(0);

  // Exam Bank Filter
  const [examFilter, setExamFilter] = useState<string>('ALL');

  const currentModule = SYLLABUS_MODULES.find(m => m.id === activeTab);

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Aggregate all exam questions for the master bank
  const allExamQuestions = SYLLABUS_MODULES.flatMap(m => 
    m.examQuestions.map(q => ({ ...q, moduleTitle: m.title.split('—')[1] || m.title }))
  );

  const filteredQuestions = allExamQuestions.filter(q => 
    examFilter === 'ALL' || q.marks === examFilter
  );

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-green-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl border border-emerald-800">
        <div className="space-y-2">
          <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-[11px] font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>2nd Year B.Tech AIML • Java Technologies 5th Module</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Java 5th Module Classroom & Laboratory Hub
          </h2>
          <p className="text-xs text-gray-300 max-w-3xl leading-relaxed">
            In-depth academic syllabus integration covering AWT GUI programming, JDBC database connectivity, Java Servlets API life cycle, and JavaServer Pages (JSP) architecture with code demos and exam question bank.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="mt-6 flex flex-wrap gap-2 pt-2 border-t border-emerald-800/80">
          <button
            onClick={() => setActiveTab('awt')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'awt' ? 'bg-emerald-500 text-emerald-950 shadow-md' : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>A. AWT Desktop GUI</span>
          </button>

          <button
            onClick={() => setActiveTab('jdbc')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'jdbc' ? 'bg-emerald-500 text-emerald-950 shadow-md' : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>B. JDBC Database</span>
          </button>

          <button
            onClick={() => setActiveTab('servlets')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'servlets' ? 'bg-emerald-500 text-emerald-950 shadow-md' : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>C. Servlet API</span>
          </button>

          <button
            onClick={() => setActiveTab('jsp')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'jsp' ? 'bg-emerald-500 text-emerald-950 shadow-md' : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>D. JSP Pages</span>
          </button>

          <button
            onClick={() => setActiveTab('exam-bank')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
              activeTab === 'exam-bank' ? 'bg-amber-400 text-emerald-950 shadow-md' : 'bg-emerald-900/60 text-amber-200 hover:bg-emerald-800'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Viva & Exam Q&A Bank</span>
          </button>
        </div>
      </div>

      {/* Module Content */}
      {activeTab !== 'exam-bank' && currentModule && (
        <div className="space-y-6">
          
          {/* Module Heading */}
          <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm space-y-2">
            <h3 className="text-lg font-black text-emerald-950">{currentModule.title}</h3>
            <p className="text-xs font-semibold text-emerald-700">{currentModule.subtitle}</p>
            <p className="text-xs text-gray-600 leading-relaxed pt-1">{currentModule.overview}</p>
          </div>

          {/* Special Interactive Section for AWT: Layout Manager Simulator */}
          {activeTab === 'awt' && (
            <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100">
                <div>
                  <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Layout className="w-4 h-4 text-emerald-700" />
                    Interactive AWT Layout Manager Visualizer
                  </h4>
                  <p className="text-xs text-gray-500">
                    Test how FlowLayout, BorderLayout, GridLayout, and CardLayout position components dynamically.
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {(['BorderLayout', 'FlowLayout', 'GridLayout', 'CardLayout'] as const).map((lm) => (
                    <button
                      key={lm}
                      onClick={() => setSelectedLayout(lm)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        selectedLayout === lm
                          ? 'bg-emerald-700 text-white shadow-sm'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {lm}
                    </button>
                  ))}
                </div>
              </div>

              {/* Layout Sandbox Render Box */}
              <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-xl min-h-[220px] flex flex-col justify-center">
                {selectedLayout === 'BorderLayout' && (
                  <div className="w-full h-48 border-2 border-dashed border-emerald-400 p-2 grid grid-rows-3 grid-cols-3 gap-2 text-xs font-bold text-center">
                    <div className="col-span-3 bg-emerald-700 text-white p-2 rounded flex items-center justify-center">
                      BorderLayout.NORTH (e.g. Header Panel)
                    </div>
                    <div className="bg-emerald-600 text-white p-2 rounded flex items-center justify-center">
                      WEST
                    </div>
                    <div className="bg-emerald-100 text-emerald-950 border border-emerald-400 p-2 rounded flex items-center justify-center font-extrabold">
                      CENTER (Main Outpass Form)
                    </div>
                    <div className="bg-emerald-600 text-white p-2 rounded flex items-center justify-center">
                      EAST
                    </div>
                    <div className="col-span-3 bg-emerald-800 text-white p-2 rounded flex items-center justify-center">
                      BorderLayout.SOUTH (Submit & Reset Buttons)
                    </div>
                  </div>
                )}

                {selectedLayout === 'FlowLayout' && (
                  <div className="w-full border-2 border-dashed border-emerald-400 p-4 rounded-lg flex flex-wrap gap-3 items-center justify-center">
                    {['Label: ID', 'TextField: 23M41A6601', 'Label: Name', 'TextField: Srivally', 'Choice: Reason', 'Button: Submit'].map((item, idx) => (
                      <div key={idx} className="bg-emerald-600 text-white px-3 py-2 rounded-lg text-xs font-bold shadow-sm">
                        {item}
                      </div>
                    ))}
                  </div>
                )}

                {selectedLayout === 'GridLayout' && (
                  <div className="w-full border-2 border-dashed border-emerald-400 p-3 rounded-lg grid grid-cols-2 gap-3 text-xs font-bold text-center">
                    <div className="bg-emerald-100 text-emerald-900 border border-emerald-300 p-2.5 rounded">Row 1, Col 1: Roll No Label</div>
                    <div className="bg-white border border-gray-300 p-2.5 rounded">Row 1, Col 2: [ 23M41A6601 ]</div>
                    <div className="bg-emerald-100 text-emerald-900 border border-emerald-300 p-2.5 rounded">Row 2, Col 1: Destination</div>
                    <div className="bg-white border border-gray-300 p-2.5 rounded">Row 2, Col 2: [ Secunderabad ]</div>
                    <div className="bg-emerald-100 text-emerald-900 border border-emerald-300 p-2.5 rounded">Row 3, Col 1: Reason</div>
                    <div className="bg-white border border-gray-300 p-2.5 rounded">Row 3, Col 2: [ Home Visit ▼ ]</div>
                  </div>
                )}

                {selectedLayout === 'CardLayout' && (
                  <div className="w-full border-2 border-dashed border-emerald-400 p-4 rounded-lg space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-950">Card Stack Simulator (Deck of Cards)</span>
                      <div className="space-x-2">
                        <button
                          onClick={() => setActiveCardIndex(0)}
                          className={`px-2.5 py-1 rounded text-xs font-bold ${activeCardIndex === 0 ? 'bg-emerald-700 text-white' : 'bg-gray-200'}`}
                        >
                          Card 1: Student
                        </button>
                        <button
                          onClick={() => setActiveCardIndex(1)}
                          className={`px-2.5 py-1 rounded text-xs font-bold ${activeCardIndex === 1 ? 'bg-emerald-700 text-white' : 'bg-gray-200'}`}
                        >
                          Card 2: Dates
                        </button>
                        <button
                          onClick={() => setActiveCardIndex(2)}
                          className={`px-2.5 py-1 rounded text-xs font-bold ${activeCardIndex === 2 ? 'bg-emerald-700 text-white' : 'bg-gray-200'}`}
                        >
                          Card 3: Submit
                        </button>
                      </div>
                    </div>

                    <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm text-xs">
                      {activeCardIndex === 0 && <div>Step 1: Student Roll No <strong>23M41A6601</strong> & Name <strong>Srivally Thandury</strong></div>}
                      {activeCardIndex === 1 && <div>Step 2: Departure <strong>2026-10-17 16:30</strong> → Return <strong>2026-10-19 08:30</strong></div>}
                      {activeCardIndex === 2 && <div className="text-emerald-800 font-bold">Step 3: Ready to submit AWT Outpass to MySQL via JDBC!</div>}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Key Syllabus Concepts */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-emerald-950">
              Core Theoretical Concepts & Architecture
            </h4>

            {currentModule.keyConcepts.map((concept, idx) => (
              <div key={idx} className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm space-y-2">
                <h5 className="text-xs font-extrabold text-emerald-900">{concept.heading}</h5>
                <pre className="text-xs text-gray-700 font-sans whitespace-pre-wrap leading-relaxed">
                  {concept.description}
                </pre>
                {concept.codeSnippet && (
                  <div className="mt-2 bg-slate-900 rounded-lg p-3 text-slate-200 font-mono text-[11px] overflow-x-auto">
                    <code>{concept.codeSnippet}</code>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Practical Lab Code File */}
          <div className="bg-slate-900 rounded-2xl shadow-xl border border-slate-800 overflow-hidden">
            <div className="bg-slate-950 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-mono text-xs font-bold text-emerald-400">
                  {currentModule.practicalCode.fileName}
                </span>
                <p className="text-[11px] text-slate-400">{currentModule.practicalCode.description}</p>
              </div>

              <button
                onClick={() => handleCopy(currentModule.practicalCode.code, currentModule.id)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition-colors border border-slate-700"
              >
                {copiedCode === currentModule.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Lab Code</span>
                  </>
                )}
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-x-auto max-h-[500px] overflow-y-auto">
              <pre className="font-mono text-xs text-slate-200 leading-relaxed">
                <code>{currentModule.practicalCode.code}</code>
              </pre>
            </div>
          </div>

          {/* Exam Questions for this module */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-700" />
              Probable University Examination Questions (2M / 5M / 10M / Viva)
            </h4>

            {currentModule.examQuestions.map((q, idx) => (
              <div key={idx} className="bg-white rounded-xl p-4 border border-emerald-100 shadow-sm space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    q.marks === '2 Marks' ? 'bg-blue-100 text-blue-800' :
                    q.marks === '5 Marks' ? 'bg-emerald-100 text-emerald-800' :
                    q.marks === '10 Marks' ? 'bg-amber-100 text-amber-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {q.marks}
                  </span>
                </div>
                <h5 className="text-xs font-bold text-gray-900">{q.question}</h5>
                <p className="text-xs text-gray-600 leading-relaxed bg-gray-50 p-2.5 rounded-lg border border-gray-100">
                  <strong className="text-emerald-900">Model Answer: </strong>
                  {q.answer}
                </p>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* Master Exam Question Bank View */}
      {activeTab === 'exam-bank' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-gray-900">
                Master Examination & Viva Voce Question Bank
              </h3>
              <p className="text-xs text-gray-500">
                Curated questions spanning AWT, JDBC, Servlets, and JSP modules for JNTUH semester exams.
              </p>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {['ALL', '2 Marks', '5 Marks', '10 Marks', 'Viva Voce'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setExamFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    examFilter === filter
                      ? 'bg-emerald-700 text-white shadow-sm'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredQuestions.map((q, idx) => (
              <div key={idx} className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-800">{q.moduleTitle}</span>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                    q.marks === '2 Marks' ? 'bg-blue-100 text-blue-800' :
                    q.marks === '5 Marks' ? 'bg-emerald-100 text-emerald-800' :
                    q.marks === '10 Marks' ? 'bg-amber-100 text-amber-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {q.marks}
                  </span>
                </div>
                <h4 className="text-xs sm:text-sm font-extrabold text-gray-900">{q.question}</h4>
                <div className="text-xs text-gray-700 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100/80 leading-relaxed">
                  <strong className="text-emerald-950">Examination Answer: </strong>
                  {q.answer}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
