import React, { useState } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  Building2, 
  GraduationCap, 
  Award, 
  ShieldAlert, 
  CheckCircle2, 
  Lock, 
  Save, 
  AlertCircle 
} from 'lucide-react';
import { StudentProfile } from '../types';

interface ProfileViewProps {
  student: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  student,
  onUpdateProfile
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [phone, setPhone] = useState(student.phone);
  const [parentPhone, setParentPhone] = useState(student.parentPhone);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({ phone, parentPhone });
    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn pb-12">
      
      {/* Header Profile Card */}
      <div className="bg-gradient-to-r from-emerald-900 to-green-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl border border-emerald-700/50 flex flex-col sm:flex-row items-center sm:items-start gap-6">
        <div className="relative">
          <div className="w-24 h-24 rounded-2xl bg-emerald-700 border-4 border-emerald-400 overflow-hidden shadow-lg flex items-center justify-center text-3xl font-extrabold text-white">
            {student.avatarUrl ? (
              <img src={student.avatarUrl} alt={student.name} className="w-full h-full object-cover" />
            ) : (
              'ST'
            )}
          </div>
          <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded-full border-2 border-emerald-950">
            Active Student
          </div>
        </div>

        <div className="space-y-1 text-center sm:text-left flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-2xl font-black text-white">{student.name}</h2>
              <p className="text-xs text-emerald-200 font-mono">College Roll No: {student.collegeId}</p>
            </div>
            
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-4 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-xs font-bold text-white shadow transition-colors self-center sm:self-start"
            >
              {isEditing ? 'Cancel Edit' : 'Edit Contact Info'}
            </button>
          </div>

          <p className="text-xs text-emerald-300 font-medium pt-1">
            {student.program} • {student.academicYear} ({student.semester}) • Section {student.section}
          </p>
          <p className="text-[11px] text-gray-300">
            Faculty Mentor: <strong>{student.mentorName}</strong> ({student.mentorPhone})
          </p>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2 border border-emerald-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Profile contact details updated successfully in database.</span>
        </div>
      )}

      {/* Main Profile Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Academic Records (Immutable) */}
        <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-emerald-700" />
              <span>Academic Credentials (Institutional Lock)</span>
            </h3>
            <span title="Security Locked">
              <Lock className="w-3.5 h-3.5 text-gray-400" />
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-gray-500">Degree & Branch</span>
              <strong className="text-gray-900">{student.program}</strong>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-gray-500">Current Semester</span>
              <strong className="text-gray-900">{student.semester}</strong>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-gray-500">Cumulative CGPA</span>
              <span className="font-bold text-emerald-700">{student.cgpa} / 10.0</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-gray-500">Current Attendance</span>
              <span className="font-bold text-emerald-700">{student.attendancePercentage}% (Eligible)</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-gray-500">Active Backlogs</span>
              <span className="font-bold text-gray-900">{student.backlogs}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-gray-500">Registered Credits</span>
              <strong className="text-gray-900">{student.currentCredits} Credits</strong>
            </div>
          </div>

          <div className="p-3 bg-gray-50 rounded-xl text-[11px] text-gray-500 flex items-start gap-1.5">
            <ShieldAlert className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
            <span>Academic records, CGPA, and Attendance are synchronised directly with the HITAM Examination Cell and cannot be modified by students.</span>
          </div>
        </div>

        {/* Hostel & Contact Particulars */}
        <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-950 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-emerald-700" />
              <span>Campus Residence & Communication</span>
            </h3>
            {isEditing && (
              <span className="text-[10px] font-bold text-amber-600 bg-amber-100 px-2 py-0.5 rounded-full">
                Edit Mode
              </span>
            )}
          </div>

          {isEditing ? (
            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div>
                <label className="block text-gray-700 font-bold mb-1">Student Mobile Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-gray-300 focus:border-emerald-600 outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-700 font-bold mb-1">Parent Mobile Number (Emergency)</label>
                <input
                  type="tel"
                  value={parentPhone}
                  onChange={(e) => setParentPhone(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-gray-300 focus:border-emerald-600 outline-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center justify-center space-x-1.5 shadow"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Contact Changes</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Student Email</span>
                <strong className="text-gray-900 font-mono">{student.email}</strong>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Student Phone</span>
                <strong className="text-gray-900">{student.phone}</strong>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Parent/Guardian</span>
                <strong className="text-gray-900">{student.parentName}</strong>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Parent Phone</span>
                <strong className="text-emerald-800 font-mono">{student.parentPhone}</strong>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Hostel Residence</span>
                <strong className="text-gray-900">{student.hostelBlock}</strong>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-gray-500">Room Allocation</span>
                <strong className="text-gray-900">{student.hostelRoom}</strong>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
