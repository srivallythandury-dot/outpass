import React, { useState } from 'react';
import { 
  Code2, 
  Download, 
  Copy, 
  Check, 
  FileText, 
  Folder, 
  Terminal, 
  Layers, 
  FileCode,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import JSZip from 'jszip';
import { JAVA_PROJECT_FILES, JavaProjectFile } from '../data/javaProjectCode';

export const JavaCodeRepoView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<JavaProjectFile>(JAVA_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      const zip = new JSZip();

      // Create folder HITAM-Outpass
      const rootFolder = zip.folder('HITAM-Outpass');

      JAVA_PROJECT_FILES.forEach((file) => {
        rootFolder?.file(file.path, file.code);
      });

      // Generate the ZIP file
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HITAM-Smart-Outpass-Java-Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate ZIP:', err);
      alert('Error generating project ZIP.');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-green-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl border border-emerald-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-emerald-700/60 text-emerald-200 text-xs font-semibold">
              <Code2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Complete Maven & Spring Boot 3 Source Tree</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Java Backend Code Repository
            </h2>
            <p className="text-xs text-gray-300">
              Clean architecture: Spring Boot 3.2, Spring Data JPA, Spring Security, MySQL Connector, and REST Controllers.
            </p>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-400 hover:to-green-400 text-emerald-950 font-extrabold text-xs rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center space-x-2 self-start md:self-center disabled:opacity-60 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{isDownloading ? 'Bundling ZIP...' : 'Download Full Maven Project (.zip)'}</span>
          </button>
        </div>
      </div>

      {/* Explorer + Code Viewer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column (File Tree Explorer - 4 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-gray-200 p-4 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-gray-100">
            <div className="flex items-center space-x-2">
              <Folder className="w-4 h-4 text-emerald-700" />
              <span className="text-xs font-bold uppercase tracking-wider text-gray-800">
                HITAM-Outpass /
              </span>
            </div>
            <span className="text-[10px] text-gray-400 font-mono">
              {JAVA_PROJECT_FILES.length} Files
            </span>
          </div>

          <div className="space-y-1">
            {JAVA_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-xs transition-all flex items-start space-x-2.5 ${
                    isSelected
                      ? 'bg-emerald-800 text-white font-bold shadow-sm'
                      : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <FileCode className={`w-4 h-4 shrink-0 mt-0.5 ${isSelected ? 'text-emerald-300' : 'text-emerald-700'}`} />
                  <div className="truncate">
                    <div className="font-mono text-[11px] truncate">{file.path}</div>
                    <div className={`text-[10px] truncate ${isSelected ? 'text-emerald-200' : 'text-gray-400'}`}>
                      {file.category}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column (Code Viewer - 8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900 rounded-2xl shadow-xl border border-slate-800 overflow-hidden flex flex-col">
          
          {/* File Header Bar */}
          <div className="bg-slate-950 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="font-mono text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span>{selectedFile.path}</span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-1">{selectedFile.description}</p>
            </div>

            <button
              onClick={handleCopy}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition-colors border border-slate-700"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="p-4 sm:p-6 overflow-x-auto max-h-[600px] overflow-y-auto">
            <pre className="font-mono text-xs text-slate-200 leading-relaxed">
              <code>{selectedFile.code}</code>
            </pre>
          </div>
        </div>

      </div>

    </div>
  );
};
