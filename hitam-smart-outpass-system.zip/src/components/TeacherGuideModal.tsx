import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  Terminal, 
  Code2, 
  Database, 
  Server, 
  ChevronRight, 
  ChevronLeft, 
  BookOpen,
  Copy,
  Check,
  Sparkles
} from 'lucide-react';

interface TeacherGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Step {
  stepNumber: number;
  title: string;
  subtitle: string;
  explanation: string;
  terminalCommand?: string;
  keyAction: string;
  verificationTip: string;
}

export const TeacherGuideModal: React.FC<TeacherGuideModalProps> = ({
  isOpen,
  onClose
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const [copiedCmd, setCopiedCmd] = useState(false);

  if (!isOpen) return null;

  const STEPS: Step[] = [
    {
      stepNumber: 1,
      title: 'Prerequisites & Maven pom.xml Setup',
      subtitle: 'Verify Java 17 and create the Maven project descriptor',
      explanation: 'Before writing Java code, ensure Java Development Kit 17 (or compatible) and Apache Maven 3.8+ are installed. Maven automates downloading Spring Boot starters, MySQL drivers, and Spring Security libraries.',
      terminalCommand: 'java -version\nmvn -version',
      keyAction: 'Create the project folder HITAM-Outpass/ and place the complete pom.xml file in the project root directory.',
      verificationTip: 'In your VS Code terminal, running "mvn clean compile" will download all dependencies and verify zero syntax errors.'
    },
    {
      stepNumber: 2,
      title: 'MySQL Community Server & Database Creation',
      subtitle: 'Create hitam_outpass_db and initialize schemas',
      explanation: 'Open MySQL Workbench or MySQL Command Line client. Execute the schema.sql script to build the tables: students, staff, outpass_requests, notifications, and outpass_approval_history.',
      terminalCommand: 'mysql -u root -p\nCREATE DATABASE hitam_outpass_db;\nsource database/schema.sql;',
      keyAction: 'Verify that foreign keys between outpass_requests and students/staff are configured with proper CASCADE rules.',
      verificationTip: 'Run "SHOW TABLES IN hitam_outpass_db;" — you should see 5 tables created.'
    },
    {
      stepNumber: 3,
      title: 'Spring Boot application.properties Configuration',
      subtitle: 'Configure database connection URL, credentials, and HikariCP pool',
      explanation: 'Spring Boot connects to MySQL via the JDBC URL specified in src/main/resources/application.properties. HikariCP manages an efficient connection pool for multiple student users.',
      keyAction: 'Set spring.datasource.username=root and spring.datasource.password to your local MySQL password.',
      verificationTip: 'Set spring.jpa.hibernate.ddl-auto=update so Hibernate automatically syncs table changes safely without data loss.'
    },
    {
      stepNumber: 4,
      title: 'JPA Entities & Spring Data Repositories',
      subtitle: 'Build Student.java, OutpassRequest.java, and Repository interfaces',
      explanation: 'Spring Data JPA converts Java classes into MySQL database rows. By creating interfaces extending JpaRepository<OutpassRequest, Long>, you get automatic save(), findById(), and custom query methods without writing manual SQL.',
      keyAction: 'Place Student.java and OutpassRequest.java in package in.hitam.outpass.model.',
      verificationTip: 'Use @Enumerated(EnumType.STRING) for OutpassStatus so "PENDING", "APPROVED", and "REJECTED" are readable in MySQL.'
    },
    {
      stepNumber: 5,
      title: 'Spring Security & Password Hashing',
      subtitle: 'Enforce BCryptPasswordEncoder & Role-Based Access Control',
      explanation: 'Passwords must NEVER be saved in plain text. Spring Security hashes passwords using BCrypt. SecurityConfig.java ensures students cannot access /api/staff/** endpoints.',
      keyAction: 'Configure SecurityFilterChain with .requestMatchers("/api/staff/**").hasAnyRole("HOD", "WARDEN").',
      verificationTip: 'Test logging in with invalid passwords to verify 401 Unauthorized responses.'
    },
    {
      stepNumber: 6,
      title: 'Outpass Business Logic & Validations',
      subtitle: 'Ensure return date/time is after departure and generate request IDs',
      explanation: 'OutpassService.java handles institutional rules: departure times must be chronological, student attendance must be validated, and unique IDs like HITAM-OP-2026-XXXX must be created.',
      keyAction: 'Never mark a request Approved automatically upon submission. Initially assign status as PENDING.',
      verificationTip: 'Verify that trying to set a return time earlier than leaving time throws an IllegalArgumentException.'
    },
    {
      stepNumber: 7,
      title: 'REST API Controllers',
      subtitle: 'Expose REST endpoints for React / HTML frontend integration',
      explanation: 'Controllers map HTTP requests (POST /api/outpasses, GET /api/outpasses, PATCH /api/staff/outpasses/{id}/approve) to service methods and return JSON responses.',
      keyAction: 'Annotate controllers with @RestController, @RequestMapping, and @CrossOrigin.',
      verificationTip: 'Test endpoints using VS Code Thunder Client or cURL.'
    },
    {
      stepNumber: 8,
      title: 'Responsive Frontend Web Portal',
      subtitle: 'Connect the dark forest green HITAM dashboard',
      explanation: 'The frontend portal provides intuitive dashboards for students and staff with real-time feedback, status tracking, and digital printable gate passes with QR tokens.',
      keyAction: 'Host static HTML/CSS/JS in src/main/resources/static or run React with Vite on port 3000.',
      verificationTip: 'Check responsiveness on mobile viewports to ensure table rows wrap gracefully into readable cards.'
    },
    {
      stepNumber: 9,
      title: 'Starting & Testing in VS Code',
      subtitle: 'Run Spring Boot and execute complete end-to-end test cases',
      explanation: 'Start the embedded Tomcat web server using the Maven wrapper or command line. Access http://localhost:8080 in your browser.',
      terminalCommand: 'mvn clean compile\nmvn spring-boot:run',
      keyAction: 'Test flow: (1) Login as student 23M41A6601 -> (2) Apply outpass -> (3) Switch to HOD -> (4) Approve request with remarks -> (5) View Gate Pass.',
      verificationTip: 'Restart the backend and verify that your submitted outpass still exists in MySQL!'
    },
    {
      stepNumber: 10,
      title: 'Academic Viva Voce & Presentation Defense',
      subtitle: 'Ace your 2nd Year B.Tech project presentation',
      explanation: 'Examiners frequently ask about: (1) Why Spring Boot over standalone Tomcat? (2) PreparedStatement vs Statement in JDBC, (3) Servlet Life Cycle (init, service, destroy), (4) MVC architecture flow.',
      keyAction: 'Review the questions in the "Java 5th Module Hub -> Viva & Exam Q&A Bank" tab in this application.',
      verificationTip: 'Be prepared to explain how the database transaction commits approval history atomically with outpass status.'
    }
  ];

  const current = STEPS[activeStep];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-emerald-300 space-y-6 animate-scaleUp">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Step-by-Step Teacher Guide
                </span>
                <span className="text-xs font-semibold text-gray-400">
                  Step {current.stepNumber} of {STEPS.length}
                </span>
              </div>
              <h3 className="text-lg font-black text-gray-900 mt-0.5">
                {current.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        <div className="grid grid-cols-10 gap-1.5">
          {STEPS.map((s, idx) => (
            <button
              key={s.stepNumber}
              onClick={() => setActiveStep(idx)}
              className={`h-2 rounded-full transition-all ${
                idx === activeStep
                  ? 'bg-emerald-600 scale-y-125'
                  : idx < activeStep
                  ? 'bg-emerald-300'
                  : 'bg-gray-200'
              }`}
              title={`Step ${s.stepNumber}: ${s.title}`}
            />
          ))}
        </div>

        {/* Step Details Body */}
        <div className="space-y-4 text-xs">
          <div className="text-xs font-bold text-emerald-800 bg-emerald-50 p-2 rounded-lg">
            {current.subtitle}
          </div>

          <p className="text-xs text-gray-700 leading-relaxed">
            {current.explanation}
          </p>

          {/* Terminal Command Box if present */}
          {current.terminalCommand && (
            <div className="bg-slate-900 rounded-xl p-3.5 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1.5 font-mono">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  Terminal Command (Windows / VS Code):
                </span>
                <button
                  onClick={() => handleCopy(current.terminalCommand!)}
                  className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold"
                >
                  {copiedCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="font-mono text-emerald-300 text-xs overflow-x-auto">
                <code>{current.terminalCommand}</code>
              </pre>
            </div>
          )}

          {/* Key Implementation Action */}
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 space-y-1">
            <span className="font-bold uppercase text-[10px] tracking-wider block text-amber-800">
              Key Action for this step:
            </span>
            <p>{current.keyAction}</p>
          </div>

          {/* Verification Tip */}
          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Student Checkpoint: </span>
              <span>{current.verificationTip}</span>
            </div>
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <button
            onClick={() => setActiveStep(prev => Math.max(0, prev - 1))}
            disabled={activeStep === 0}
            className="px-4 py-2 rounded-xl border border-gray-300 text-xs font-semibold text-gray-700 hover:bg-gray-50 disabled:opacity-40 flex items-center gap-1"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous Step</span>
          </button>

          <div className="text-xs text-gray-500 font-medium">
            Step {activeStep + 1} of {STEPS.length}
          </div>

          <button
            onClick={() => {
              if (activeStep < STEPS.length - 1) {
                setActiveStep(prev => prev + 1);
              } else {
                onClose();
              }
            }}
            className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold shadow flex items-center gap-1"
          >
            <span>{activeStep === STEPS.length - 1 ? 'Finish Guide' : 'Next Step'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
