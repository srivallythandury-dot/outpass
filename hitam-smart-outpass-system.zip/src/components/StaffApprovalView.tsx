import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Clock, 
  User, 
  Calendar, 
  MapPin, 
  Phone, 
  MessageSquare, 
  FileText, 
  UserCheck,
  Shield,
  AlertTriangle
} from 'lucide-react';
import { OutpassRequest, StaffProfile } from '../types';

interface StaffApprovalViewProps {
  outpasses: OutpassRequest[];
  staffMembers: StaffProfile[];
  activeStaffRole: 'HOD' | 'WARDEN';
  onSwitchStaffRole: (role: 'HOD' | 'WARDEN') => void;
  onProcessDecision: (
    outpassId: string, 
    approved: boolean, 
    remarks: string, 
    staffName: string, 
    staffRole: 'HOD' | 'WARDEN'
  ) => void;
}

export const StaffApprovalView: React.FC<StaffApprovalViewProps> = ({
  outpasses,
  staffMembers,
  activeStaffRole,
  onSwitchStaffRole,
  onProcessDecision
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'PENDING' | 'PROCESSED' | 'ALL'>('PENDING');
  const [selectedOutpass, setSelectedOutpass] = useState<OutpassRequest | null>(null);
  const [decisionMode, setDecisionMode] = useState<'APPROVE' | 'REJECT' | null>(null);
  const [remarks, setRemarks] = useState('');
  const [remarksError, setRemarksError] = useState('');

  const currentStaff = staffMembers.find((s) => s.role === activeStaffRole) || staffMembers[0];

  const pendingRequests = outpasses.filter((op) => op.status === 'PENDING');
  const processedRequests = outpasses.filter((op) => op.status !== 'PENDING');

  const displayedList = outpasses.filter((op) => {
    const matchesStatus = 
      statusFilter === 'ALL' ||
      (statusFilter === 'PENDING' && op.status === 'PENDING') ||
      (statusFilter === 'PROCESSED' && op.status !== 'PENDING');

    const matchesSearch = 
      op.collegeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      op.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      op.requestNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      op.destination.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesStatus && matchesSearch;
  });

  const handleOpenDecision = (outpass: OutpassRequest, mode: 'APPROVE' | 'REJECT') => {
    setSelectedOutpass(outpass);
    setDecisionMode(mode);
    setRemarks(
      mode === 'APPROVE' 
        ? activeStaffRole === 'HOD' 
          ? 'Attendance verified (>85%). Permitted to leave campus.' 
          : 'Parent consent verified via phone call. Gate clearance granted.'
        : 'Permission denied due to upcoming academic schedule or incomplete details.'
    );
    setRemarksError('');
  };

  const handleConfirmDecision = () => {
    if (!remarks.trim()) {
      setRemarksError('Please provide administrative remarks for the audit trail.');
      return;
    }

    if (!selectedOutpass || !decisionMode) return;

    onProcessDecision(
      selectedOutpass.id,
      decisionMode === 'APPROVE',
      remarks.trim(),
      `${currentStaff.name} (${currentStaff.role === 'HOD' ? 'HOD AIML' : 'Chief Warden'})`,
      currentStaff.role
    );

    setSelectedOutpass(null);
    setDecisionMode(null);
    setRemarks('');
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* Authority Banner with Active Staff Selector */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-green-950 text-white p-6 rounded-2xl shadow-xl border border-emerald-800/80">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-[11px] font-bold">
              <Shield className="w-3.5 h-3.5" />
              <span>Administrative Approval Authority Portal</span>
            </div>
            <h2 className="text-xl font-extrabold text-white">
              Institutional Outpass Review Desk
            </h2>
            <p className="text-xs text-gray-300">
              Logged in as: <strong className="text-white">{currentStaff.name}</strong> •{' '}
              <span className="text-emerald-300 font-mono">{currentStaff.designation}</span> ({currentStaff.department})
            </p>
          </div>

          {/* Switch Role Tabs (HOD vs Warden) */}
          <div className="bg-emerald-900/60 p-1 rounded-xl border border-emerald-700/60 flex items-center space-x-1 self-start lg:self-center">
            <button
              onClick={() => onSwitchStaffRole('HOD')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeStaffRole === 'HOD'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-emerald-200 hover:text-white'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>HOD Desk (AIML)</span>
            </button>

            <button
              onClick={() => onSwitchStaffRole('WARDEN')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeStaffRole === 'WARDEN'
                  ? 'bg-amber-400 text-emerald-950 shadow-md'
                  : 'text-emerald-200 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Hostel Warden Desk</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Status Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-amber-200 shadow-sm flex items-center space-x-3 bg-amber-50/30">
          <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
            <Clock className="w-5 h-5 text-amber-700" />
          </div>
          <div>
            <div className="text-2xl font-black text-amber-900">{pendingRequests.length}</div>
            <div className="text-xs font-medium text-amber-700">Awaiting Action</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-emerald-200 shadow-sm flex items-center space-x-3 bg-emerald-50/30">
          <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
            <CheckCircle className="w-5 h-5 text-emerald-700" />
          </div>
          <div>
            <div className="text-2xl font-black text-emerald-900">
              {outpasses.filter(o => o.status === 'APPROVED').length}
            </div>
            <div className="text-xs font-medium text-emerald-700">Total Approved</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-gray-100 text-gray-800 flex items-center justify-center font-bold">
            <FileText className="w-5 h-5 text-gray-700" />
          </div>
          <div>
            <div className="text-2xl font-black text-gray-900">{processedRequests.length}</div>
            <div className="text-xs font-medium text-gray-600">History Logged</div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <button
            onClick={() => setStatusFilter('PENDING')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'PENDING'
                ? 'bg-amber-500 text-emerald-950 shadow-sm'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Pending Requests ({pendingRequests.length})
          </button>
          <button
            onClick={() => setStatusFilter('PROCESSED')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'PROCESSED'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Processed History
          </button>
          <button
            onClick={() => setStatusFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              statusFilter === 'ALL'
                ? 'bg-gray-800 text-white shadow-sm'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All
          </button>
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search student roll, name, or pass ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-gray-200 focus:border-emerald-600 outline-none"
          />
        </div>
      </div>

      {/* Requests List */}
      {displayedList.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-dashed border-gray-300">
          <ShieldCheck className="w-12 h-12 text-gray-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-gray-700">No requests in this queue</h3>
          <p className="text-xs text-gray-400 mt-1">
            All pending outpass applications have been reviewed or filter produced no results.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayedList.map((op) => {
            const isPending = op.status === 'PENDING';

            return (
              <div
                key={op.id}
                className="bg-white rounded-2xl p-5 border border-gray-200 hover:border-emerald-300 shadow-sm transition-all space-y-4"
              >
                {/* Header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100">
                  <div className="flex items-center space-x-3">
                    <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center font-bold text-emerald-800">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-extrabold text-sm text-gray-900">{op.studentName}</span>
                        <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                          {op.collegeId}
                        </span>
                        <span className="text-xs text-gray-500">• {op.department}</span>
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        Ref: <strong className="font-mono text-gray-700">{op.requestNumber}</strong> | Submitted: {op.submissionDate}
                      </div>
                    </div>
                  </div>

                  {/* Actions or Status Badge */}
                  <div className="flex items-center space-x-2 self-start sm:self-center">
                    {isPending ? (
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleOpenDecision(op, 'APPROVE')}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-all"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => handleOpenDecision(op, 'REJECT')}
                          className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-all"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </div>
                    ) : (
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        op.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {op.status}
                      </span>
                    )}
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs bg-gray-50 p-3.5 rounded-xl">
                  <div>
                    <span className="text-gray-400 text-[10px] uppercase font-bold block">Reason & Purpose</span>
                    <strong className="text-gray-900">{op.reason}</strong>
                  </div>
                  <div>
                    <span className="text-gray-400 text-[10px] uppercase font-bold block">Destination</span>
                    <span className="text-gray-800 font-medium flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-emerald-600 shrink-0" />
                      {op.destination}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 text-[10px] uppercase font-bold block">Departure Window</span>
                    <span className="text-gray-800 font-medium">
                      {op.outpassDate} at {op.leavingTime}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 text-[10px] uppercase font-bold block">Return Time</span>
                    <span className="text-gray-800 font-medium">
                      {op.expectedReturnDate} at {op.expectedReturnTime}
                    </span>
                  </div>
                </div>

                {/* Student explanation & Parent Contact */}
                <div className="text-xs text-gray-700 space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-gray-500">Student Note:</span>
                    <span className="italic">"{op.additionalExplanation}"</span>
                  </div>
                  <div className="flex items-center space-x-2 text-emerald-800">
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Parent/Guardian Contact: <strong>{op.parentContact}</strong></span>
                  </div>
                </div>

                {/* Existing remarks if any */}
                {(op.hodApproval || op.wardenApproval) && (
                  <div className="pt-2 border-t border-gray-100 text-xs text-gray-600 space-y-1 bg-emerald-50/40 p-2.5 rounded-lg">
                    {op.hodApproval && (
                      <div>
                        <strong>HOD ({op.hodApproval.staffName}): </strong>
                        <span>{op.hodApproval.remarks} ({op.hodApproval.timestamp})</span>
                      </div>
                    )}
                    {op.wardenApproval && (
                      <div>
                        <strong>Warden ({op.wardenApproval.staffName}): </strong>
                        <span>{op.wardenApproval.remarks} ({op.wardenApproval.timestamp})</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Decision Remarks Confirmation Modal */}
      {selectedOutpass && decisionMode && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-200 space-y-4 animate-scaleUp">
            
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center space-x-2">
                {decisionMode === 'APPROVE' ? (
                  <CheckCircle className="w-6 h-6 text-emerald-600" />
                ) : (
                  <XCircle className="w-6 h-6 text-red-600" />
                )}
                <h3 className="font-bold text-base text-gray-900">
                  {decisionMode === 'APPROVE' ? 'Approve Outpass Request' : 'Reject Outpass Request'}
                </h3>
              </div>
              <button
                onClick={() => { setSelectedOutpass(null); setDecisionMode(null); }}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>

            <div className="bg-gray-50 p-3 rounded-xl text-xs space-y-1">
              <div>Student: <strong>{selectedOutpass.studentName}</strong> ({selectedOutpass.collegeId})</div>
              <div>Pass ID: <strong className="font-mono">{selectedOutpass.requestNumber}</strong></div>
              <div>Destination: <strong>{selectedOutpass.destination}</strong></div>
              <div>Reviewer Authority: <strong>{currentStaff.name}</strong> [{currentStaff.role}]</div>
            </div>

            {/* Remarks Input */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                Administrative Remarks & Instructions <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={3}
                value={remarks}
                onChange={(e) => {
                  setRemarks(e.target.value);
                  if (remarksError) setRemarksError('');
                }}
                placeholder="Enter remarks for the student & gate register..."
                className="w-full text-xs p-3 rounded-xl border border-gray-200 focus:border-emerald-600 outline-none"
              />
              {remarksError && (
                <p className="text-[11px] text-red-500 mt-1">{remarksError}</p>
              )}
            </div>

            <div className="flex justify-end space-x-3 pt-2 border-t border-gray-100">
              <button
                onClick={() => { setSelectedOutpass(null); setDecisionMode(null); }}
                className="px-4 py-2 border border-gray-300 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDecision}
                className={`px-5 py-2 rounded-xl text-white text-xs font-bold shadow ${
                  decisionMode === 'APPROVE'
                    ? 'bg-emerald-600 hover:bg-emerald-500'
                    : 'bg-red-600 hover:bg-red-500'
                }`}
              >
                Confirm {decisionMode === 'APPROVE' ? 'Approval' : 'Rejection'}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
