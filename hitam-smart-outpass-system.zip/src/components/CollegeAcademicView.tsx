import React, { useState } from 'react';
import { 
  Building2, 
  GraduationCap, 
  BookOpen, 
  Award, 
  Leaf, 
  CheckCircle, 
  MapPin, 
  Globe, 
  Sparkles,
  Users
} from 'lucide-react';
import { ACADEMIC_COURSES } from '../data/mockData';

export const CollegeAcademicView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'college' | 'academics'>('college');

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-green-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl border border-emerald-700/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-1.5 px-3 py-0.5 rounded-full bg-emerald-700/60 text-emerald-200 text-xs font-semibold">
              <Leaf className="w-3.5 h-3.5 text-emerald-400" />
              <span>India's Premier Eco-Friendly Autonomous Campus</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              HITAM & Academic Curriculum Overview
            </h2>
            <p className="text-xs text-emerald-200">
              Hyderabad Institute of Technology and Management • Department of AIML
            </p>
          </div>

          <div className="bg-emerald-800/80 p-1 rounded-xl border border-emerald-600/50 flex space-x-1 self-start sm:self-center">
            <button
              onClick={() => setActiveTab('college')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'college' ? 'bg-emerald-500 text-emerald-950 shadow' : 'text-emerald-200 hover:text-white'
              }`}
            >
              College Profile
            </button>
            <button
              onClick={() => setActiveTab('academics')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                activeTab === 'academics' ? 'bg-emerald-500 text-emerald-950 shadow' : 'text-emerald-200 hover:text-white'
              }`}
            >
              AIML Curriculum
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'college' ? (
        <div className="space-y-6">
          {/* Institutional Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                <Award className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-gray-900">Accreditations & Honors</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Autonomous status conferred by UGC. Accredited with <strong>NAAC 'A+' Grade</strong> and NBA for high academic standards and student outcomes.
              </p>
            </div>

            <div className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                <Leaf className="w-5 h-5 text-emerald-600" />
              </div>
              <h4 className="text-sm font-bold text-gray-900">India's First Green Campus</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Awarded LEED Silver Certification. Powered by solar micro-grids, lush natural flora, rainwater harvesting, and zero-waste environmental governance.
              </p>
            </div>

            <div className="bg-white rounded-xl p-5 border border-emerald-100 shadow-sm space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                <Users className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-gray-900">Doing Engineering (Project-Based)</h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Experiential learning methodology emphasizing student-built systems, software laboratories, and real-world deployment on campus.
              </p>
            </div>
          </div>

          {/* Vision & Mission */}
          <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-emerald-950 flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-700" />
              Institutional Vision & Mission
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-700 leading-relaxed">
              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100">
                <strong className="text-emerald-900 block text-sm mb-1">Our Vision:</strong>
                To be a premier institution in engineering education, nurturing self-motivated, socially responsible, eco-conscious, and industry-ready innovators.
              </div>
              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100">
                <strong className="text-emerald-900 block text-sm mb-1">Our Mission:</strong>
                Foster experiential learning ("Doing Engineering"), integrate state-of-the-art technological laboratories, and promote ethical stewardship and digital citizenship.
              </div>
            </div>
          </div>

          {/* Campus Location Details */}
          <div className="bg-emerald-950 text-white rounded-2xl p-6 shadow-md border border-emerald-800 space-y-3">
            <h4 className="text-sm font-bold text-emerald-300 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-400" />
              Campus Administrative Address
            </h4>
            <div className="text-xs text-emerald-100 space-y-1">
              <p>Hyderabad Institute of Technology and Management (HITAM)</p>
              <p>Gowdavelly (Village), Near Kompally, Medchal-Malkajgiri District, Hyderabad, Telangana - 501401</p>
              <p className="text-emerald-400 font-mono pt-1">Affiliated to JNTUH • Autonomous Institution</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Semester IV Registered Courses Table */}
          <div className="bg-white rounded-2xl p-6 border border-emerald-100 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <div>
                <h3 className="text-sm font-bold text-gray-900">
                  2nd Year B.Tech — Semester IV Course Matrix (R22/Autonomous Scheme)
                </h3>
                <p className="text-xs text-gray-500">
                  Total Active Credits: <strong className="text-emerald-800">21.0</strong> | Department of AIML
                </p>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                Regular Enrolled
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-emerald-50/80 text-emerald-950 uppercase font-bold text-[10px]">
                  <tr>
                    <th className="px-3 py-2.5">Course Code</th>
                    <th className="px-3 py-2.5">Course Title</th>
                    <th className="px-3 py-2.5">Credits</th>
                    <th className="px-3 py-2.5">Faculty In-Charge</th>
                    <th className="px-3 py-2.5">Internal Grade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {ACADEMIC_COURSES.map((course) => (
                    <tr key={course.code} className="hover:bg-gray-50 transition-colors">
                      <td className="px-3 py-2.5 font-mono font-bold text-emerald-800">{course.code}</td>
                      <td className="px-3 py-2.5 font-medium text-gray-900">{course.name}</td>
                      <td className="px-3 py-2.5 font-bold text-gray-700">{course.credits}</td>
                      <td className="px-3 py-2.5 text-gray-600">{course.faculty}</td>
                      <td className="px-3 py-2.5">
                        <span className="font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                          {course.grade}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
