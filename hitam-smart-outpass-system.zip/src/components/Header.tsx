import React, { useState } from 'react';
import { 
  Building2, 
  Bell, 
  LogOut, 
  UserCheck, 
  GraduationCap, 
  ShieldCheck, 
  Menu, 
  ChevronDown,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { Role, StudentProfile, StaffProfile } from '../types';

interface HeaderProps {
  currentRole: Role;
  onRoleChange: (role: Role) => void;
  student: StudentProfile;
  staff: StaffProfile[];
  unreadNotifCount: number;
  onOpenNotifications: () => void;
  onOpenLogin: () => void;
  onOpenGuide: () => void;
  isLoggedIn: boolean;
  onLogout: () => void;
  onToggleSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  student,
  staff,
  unreadNotifCount,
  onOpenNotifications,
  onOpenLogin,
  onOpenGuide,
  isLoggedIn,
  onLogout,
  onToggleSidebar
}) => {
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const activeStaff = staff.find(s => s.role === currentRole);

  return (
    <header className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-green-950 text-white shadow-lg sticky top-0 z-40 border-b border-emerald-800/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Left: Mobile Menu Toggle + College Emblem & Branding */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 rounded-lg bg-emerald-800/60 hover:bg-emerald-700 text-emerald-200 focus:outline-none focus:ring-2 focus:ring-emerald-400"
              aria-label="Toggle Navigation Menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Official HITAM Emblem */}
            <div className="flex items-center space-x-3 group cursor-pointer" onClick={() => onRoleChange('STUDENT')}>
              <div className="relative w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-400 via-green-500 to-emerald-700 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full bg-emerald-950 rounded-[10px] flex items-center justify-center text-emerald-300 font-extrabold tracking-wider text-xl group-hover:scale-105 transition-transform">
                  <Building2 className="w-6 h-6 text-emerald-400" />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-amber-400 text-emerald-950 text-[9px] font-black px-1.5 py-0.2 rounded-full border border-emerald-950">
                  NAAC A+
                </div>
              </div>

              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white drop-shadow-sm">
                    HITAM
                  </span>
                  <span className="hidden sm:inline-flex text-[11px] bg-emerald-800/80 text-emerald-200 border border-emerald-600/40 px-2 py-0.5 rounded-full font-semibold">
                    Autonomous
                  </span>
                </div>
                <h1 className="text-xs sm:text-sm font-semibold text-emerald-200 tracking-wide line-clamp-1">
                  Smart Outpass Management System
                </h1>
                <p className="text-[10px] text-emerald-300/80 hidden md:block">
                  Hyderabad Institute of Technology and Management • Medchal
                </p>
              </div>
            </div>
          </div>

          {/* Right Actions: Quick Role Switcher, Guide, Notifications & User Info */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            
            {/* Beginner Student Guide Button */}
            <button
              onClick={onOpenGuide}
              className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-800/70 hover:bg-emerald-700 border border-emerald-600/40 text-xs text-emerald-100 font-medium transition-colors shadow-sm"
              title="Step-by-step Java Full-Stack instructions"
            >
              <BookOpen className="w-4 h-4 text-emerald-300" />
              <span>Project Guide</span>
            </button>

            {/* Quick Portal Switcher (Student / HOD / Warden) */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-700 border border-emerald-600/50 text-xs sm:text-sm font-medium text-emerald-100 shadow-sm transition-colors"
              >
                {currentRole === 'STUDENT' ? (
                  <>
                    <GraduationCap className="w-4 h-4 text-emerald-300" />
                    <span className="hidden sm:inline">Portal:</span>
                    <span className="font-bold text-white">Student</span>
                  </>
                ) : currentRole === 'HOD' ? (
                  <>
                    <UserCheck className="w-4 h-4 text-amber-300" />
                    <span className="hidden sm:inline">Portal:</span>
                    <span className="font-bold text-amber-300">HOD Desk</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-300" />
                    <span className="hidden sm:inline">Portal:</span>
                    <span className="font-bold text-emerald-300">Chief Warden</span>
                  </>
                )}
                <ChevronDown className="w-3.5 h-3.5 text-emerald-300" />
              </button>

              {roleDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-64 bg-emerald-950/95 backdrop-blur-md rounded-xl shadow-2xl border border-emerald-700/60 p-2 z-50 text-xs"
                  onClick={() => setRoleDropdownOpen(false)}
                >
                  <div className="px-2 py-1 text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                    Switch Active Portal View:
                  </div>
                  <button
                    onClick={() => onRoleChange('STUDENT')}
                    className={`w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentRole === 'STUDENT' ? 'bg-emerald-800 text-white font-bold' : 'text-emerald-200 hover:bg-emerald-900'
                    }`}
                  >
                    <GraduationCap className="w-4 h-4 text-emerald-400" />
                    <div>
                      <div className="font-semibold">Student Portal</div>
                      <div className="text-[10px] text-emerald-300/80">Apply & track outpasses</div>
                    </div>
                  </button>

                  <button
                    onClick={() => onRoleChange('HOD')}
                    className={`w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentRole === 'HOD' ? 'bg-emerald-800 text-amber-300 font-bold' : 'text-emerald-200 hover:bg-emerald-900'
                    }`}
                  >
                    <UserCheck className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="font-semibold">HOD Approval Desk</div>
                      <div className="text-[10px] text-emerald-300/80">Dr. P. Suresh Kumar (AIML)</div>
                    </div>
                  </button>

                  <button
                    onClick={() => onRoleChange('WARDEN')}
                    className={`w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-left transition-colors ${
                      currentRole === 'WARDEN' ? 'bg-emerald-800 text-emerald-200 font-bold' : 'text-emerald-200 hover:bg-emerald-900'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <div>
                      <div className="font-semibold">Hostel Warden Desk</div>
                      <div className="text-[10px] text-emerald-300/80">Col. R. K. Sharma</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-lg bg-emerald-800/50 hover:bg-emerald-700 text-emerald-200 hover:text-white transition-colors"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-emerald-950 font-extrabold text-[10px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {unreadNotifCount}
                </span>
              )}
            </button>

            {/* User Profile Info / Logout */}
            {isLoggedIn ? (
              <div className="flex items-center space-x-2 sm:space-x-3 pl-2 border-l border-emerald-800/80">
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-bold text-white line-clamp-1">
                    {currentRole === 'STUDENT' ? student.name : activeStaff?.name}
                  </div>
                  <div className="text-[10px] text-emerald-300 font-mono">
                    {currentRole === 'STUDENT' ? student.collegeId : activeStaff?.staffId}
                  </div>
                </div>

                <div className="w-8 h-8 rounded-full bg-emerald-700 border-2 border-emerald-400/50 overflow-hidden flex items-center justify-center text-xs font-bold text-white shadow">
                  {currentRole === 'STUDENT' ? (
                    student.avatarUrl ? (
                      <img src={student.avatarUrl} alt={student.name} className="w-full h-full object-cover" />
                    ) : (
                      'ST'
                    )
                  ) : (
                    'SF'
                  )}
                </div>

                <button
                  onClick={onLogout}
                  className="p-1.5 text-emerald-300 hover:text-red-300 hover:bg-emerald-900 rounded-md transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenLogin}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold rounded-lg text-xs shadow-md transition-colors"
              >
                Sign In
              </button>
            )}

          </div>

        </div>
      </div>
    </header>
  );
};
