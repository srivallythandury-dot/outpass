import React, { useState } from 'react';
import { 
  History, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Clock3, 
  QrCode, 
  Printer, 
  X,
  Building2,
  Phone,
  FileText,
  UserCheck
} from 'lucide-react';
import { OutpassRequest, OutpassStatus, StudentProfile } from '../types';

interface OutpassHistoryProps {
  outpasses: OutpassRequest[];
  student: StudentProfile;
  onNavigateToApply: () => void;
}

export const OutpassHistory: React.FC<OutpassHistoryProps> = ({
  outpasses,
  student,
  onNavigateToApply
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOutpass, setSelectedOutpass] = useState<OutpassRequest | null>(null);
  const [showGatePassModal, setShowGatePassModal] = useState<OutpassRequest | null>(null);

  // Filter and search logic
  const filteredOutpasses = outpasses.filter((op) => {
    const matchesStatus = filterStatus === 'ALL' || op.status === filterStatus;
    const matchesQuery = 
      op.requestNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      op.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
      op.reason.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesQuery;
  });

  const getStatusBadge = (status: OutpassStatus) => {
    switch (status) {
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Approved
          </span>
        );
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <Clock3 className="w-3.5 h-3.5 text-amber-600" />
            Pending Review
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-200">
            <AlertCircle className="w-3.5 h-3.5 text-red-600" />
            Rejected
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-700 border border-gray-200">
            Cancelled
          </span>
        );
    }
  };

  const handlePrintGatePass = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-green-950 text-white p-6 rounded-2xl shadow-lg border border-emerald-700/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-700/60 flex items-center justify-center text-emerald-300">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white">Outpass Request History</h2>
            <p className="text-xs text-emerald-200/90 mt-0.5">
              Track real-time approval status, HOD remarks, and generate digital gate passes.
            </p>
          </div>
        </div>

        <button
          onClick={onNavigateToApply}
          className="self-start sm:self-center px-4 py-2 bg-emerald-400 hover:bg-emerald-300 text-emerald-950 font-bold rounded-xl text-xs shadow-md transition-colors"
        >
          + New Request
        </button>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white/90 backdrop-blur-md rounded-xl p-4 border border-emerald-100 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Status Filter Tabs */}
        <div className="flex items-center space-x-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                filterStatus === st
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {st === 'ALL' ? 'All Requests' : st.charAt(0) + st.slice(1).toLowerCase()}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by ID or destination..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-gray-200 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-400 outline-none"
          />
        </div>
      </div>

      {/* Outpass List Table / Card View */}
      {filteredOutpasses.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-dashed border-emerald-200 shadow-sm">
          <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 mx-auto mb-3">
            <History className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-gray-800">No outpass requests found</h3>
          <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
            {searchQuery
              ? `No requests matching "${searchQuery}". Try a different filter.`
              : 'You have not submitted any outpass requests under this filter category yet.'}
          </p>
          <button
            onClick={onNavigateToApply}
            className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
          >
            Apply for Outpass Now
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOutpasses.map((op) => (
            <div
              key={op.id}
              className="bg-white rounded-2xl p-5 border border-emerald-100 hover:border-emerald-300 shadow-sm hover:shadow-md transition-all space-y-4"
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-800 font-mono font-bold text-xs">
                    OP
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-sm text-emerald-950">
                        {op.requestNumber}
                      </span>
                      <span className="text-xs font-semibold text-gray-500">
                        • {op.submissionDate}
                      </span>
                    </div>
                    <div className="text-xs font-medium text-gray-700">
                      Reason: <strong className="text-emerald-900">{op.reason}</strong>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 self-start sm:self-center">
                  {getStatusBadge(op.status)}

                  {/* If Approved, show Digital Gate Pass button */}
                  {op.status === 'APPROVED' && (
                    <button
                      onClick={() => setShowGatePassModal(op)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-colors"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>Gate Pass</span>
                    </button>
                  )}

                  <button
                    onClick={() => setSelectedOutpass(op)}
                    className="px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-700 text-xs font-semibold"
                  >
                    Details
                  </button>
                </div>
              </div>

              {/* Card Journey Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-gray-50/70 p-3 rounded-xl">
                <div>
                  <span className="text-gray-400 block text-[10px] uppercase font-bold">Destination</span>
                  <span className="font-semibold text-gray-900 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    {op.destination}
                  </span>
                </div>

                <div>
                  <span className="text-gray-400 block text-[10px] uppercase font-bold">Departure Time</span>
                  <span className="font-semibold text-gray-900 flex items-center gap-1 mt-0.5">
                    <Calendar className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    {op.outpassDate} at {op.leavingTime}
                  </span>
                </div>

                <div>
                  <span className="text-gray-400 block text-[10px] uppercase font-bold">Expected Return</span>
                  <span className="font-semibold text-gray-900 flex items-center gap-1 mt-0.5">
                    <Clock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    {op.expectedReturnDate} at {op.expectedReturnTime}
                  </span>
                </div>
              </div>

              {/* Remarks Banner if reviewed by staff */}
              {(op.hodApproval || op.wardenApproval) && (
                <div className="text-xs space-y-1.5 pt-1">
                  {op.hodApproval && (
                    <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200/80 text-emerald-900 flex items-start space-x-2">
                      <UserCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">HOD Review ({op.hodApproval.staffName}): </span>
                        <span>{op.hodApproval.remarks}</span>
                        <span className="text-[10px] text-gray-500 block mt-0.5">{op.hodApproval.timestamp}</span>
                      </div>
                    </div>
                  )}

                  {op.wardenApproval && (
                    <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200/80 text-emerald-900 flex items-start space-x-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">Chief Warden Clearance: </span>
                        <span>{op.wardenApproval.remarks}</span>
                        <span className="text-[10px] text-gray-500 block mt-0.5">{op.wardenApproval.timestamp}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Digital Gate Pass Modal (Printable Pass with QR code) */}
      {showGatePassModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border-4 border-emerald-800 space-y-5 animate-scaleUp">
            
            {/* Pass Header */}
            <div className="flex items-center justify-between pb-3 border-b-2 border-emerald-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-lg bg-emerald-900 text-emerald-300 flex items-center justify-center font-bold">
                  <Building2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-emerald-950 uppercase tracking-tight">
                    Hyderabad Institute of Technology & Management
                  </h3>
                  <div className="text-[10px] font-bold text-emerald-700">
                    OFFICIAL STUDENT EXIT GATE PASS • SECURITY SLIP
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setShowGatePassModal(null)}
                className="text-gray-400 hover:text-gray-600 print:hidden"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Pass QR and Student Info */}
            <div className="grid grid-cols-3 gap-4 items-center">
              <div className="col-span-1 flex flex-col items-center justify-center p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                {/* Simulated High-Security QR Code */}
                <div className="w-24 h-24 bg-white p-2 rounded-lg border border-gray-300 shadow-inner flex flex-col items-center justify-center">
                  <div className="grid grid-cols-4 gap-1 w-full h-full p-1 bg-emerald-950 rounded">
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-emerald-950 rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-emerald-950 rounded-xs"></div>
                    <div className="bg-emerald-950 rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                    <div className="bg-white rounded-xs"></div>
                  </div>
                </div>
                <span className="text-[9px] font-mono text-emerald-900 mt-1 font-bold">
                  VERIFIED QR
                </span>
              </div>

              <div className="col-span-2 text-xs space-y-1">
                <div>
                  <span className="text-gray-400 text-[10px]">Pass Token:</span>
                  <div className="font-mono font-black text-emerald-950">{showGatePassModal.requestNumber}</div>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px]">Student:</span>
                  <div className="font-bold text-gray-900">{showGatePassModal.studentName}</div>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px]">Roll Number:</span>
                  <div className="font-mono font-bold text-emerald-800">{showGatePassModal.collegeId}</div>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px]">Branch / Sem:</span>
                  <div className="text-gray-800">{showGatePassModal.department} ({showGatePassModal.semester})</div>
                </div>
              </div>
            </div>

            {/* Travel Particulars Table */}
            <div className="bg-gray-50 rounded-xl p-3 border border-gray-200 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-gray-500">Destination:</span>
                <strong className="text-gray-900">{showGatePassModal.destination}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Reason:</span>
                <strong className="text-gray-900">{showGatePassModal.reason}</strong>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-1">
                <span className="text-gray-500">Departure Window:</span>
                <strong className="text-emerald-900">{showGatePassModal.outpassDate} at {showGatePassModal.leavingTime}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Expected Campus Return:</span>
                <strong className="text-emerald-900">{showGatePassModal.expectedReturnDate} at {showGatePassModal.expectedReturnTime}</strong>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-1">
                <span className="text-gray-500">Parent Emergency Contact:</span>
                <strong className="font-mono text-gray-900">{showGatePassModal.parentContact}</strong>
              </div>
            </div>

            {/* Dual Stamp & Signature Section */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-xl text-center">
                <div className="text-[10px] font-bold text-emerald-800 uppercase">HOD Clearance</div>
                <div className="text-xs font-serif italic text-emerald-950 font-bold my-1">
                  [Digitally Certified: Dr. P. Suresh Kumar]
                </div>
                <div className="text-[9px] text-gray-500">Dept. of AIML</div>
              </div>

              <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-xl text-center">
                <div className="text-[10px] font-bold text-emerald-800 uppercase">Warden Approval</div>
                <div className="text-xs font-serif italic text-emerald-950 font-bold my-1">
                  [Digitally Certified: Col. R. K. Sharma]
                </div>
                <div className="text-[9px] text-gray-500">Chief Hostel Warden</div>
              </div>
            </div>

            {/* Security Guard Desk Instructions */}
            <div className="text-[10px] text-gray-500 italic text-center">
              * Gate Security must scan this QR code or match College ID {showGatePassModal.collegeId} in the Smart Gate Portal before releasing student.
            </div>

            {/* Actions */}
            <div className="flex justify-end space-x-3 pt-2 print:hidden">
              <button
                onClick={() => setShowGatePassModal(null)}
                className="px-4 py-2 border border-gray-300 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Close
              </button>
              <button
                onClick={handlePrintGatePass}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center space-x-1.5 shadow"
              >
                <Printer className="w-4 h-4" />
                <span>Print Gate Slip</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Details Modal */}
      {selectedOutpass && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-emerald-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <h3 className="text-base font-bold text-gray-900">
                  Request Details: {selectedOutpass.requestNumber}
                </h3>
              </div>
              <button 
                onClick={() => setSelectedOutpass(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs space-y-3">
              <div className="grid grid-cols-2 gap-2 bg-gray-50 p-3 rounded-xl">
                <div>
                  <span className="text-gray-400 block text-[10px]">Student Name</span>
                  <span className="font-bold text-gray-900">{selectedOutpass.studentName}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[10px]">College Roll No</span>
                  <span className="font-mono font-bold text-emerald-800">{selectedOutpass.collegeId}</span>
                </div>
              </div>

              <div>
                <span className="text-gray-500 font-medium block">Reason & Destination:</span>
                <p className="text-gray-900 font-semibold">{selectedOutpass.reason} → {selectedOutpass.destination}</p>
              </div>

              <div>
                <span className="text-gray-500 font-medium block">Explanation Provided:</span>
                <p className="text-gray-800 bg-gray-50 p-2.5 rounded-lg border border-gray-100 italic">
                  "{selectedOutpass.additionalExplanation || 'No extra explanation attached.'}"
                </p>
              </div>

              {selectedOutpass.supportingDocName && (
                <div>
                  <span className="text-gray-500 font-medium block">Attached Document:</span>
                  <span className="text-emerald-700 font-semibold underline text-[11px]">
                    {selectedOutpass.supportingDocName}
                  </span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 border-t border-gray-100 pt-2">
                <div>
                  <span className="text-gray-400 block text-[10px]">Departure</span>
                  <span className="font-semibold text-gray-800">{selectedOutpass.outpassDate} at {selectedOutpass.leavingTime}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[10px]">Return</span>
                  <span className="font-semibold text-gray-800">{selectedOutpass.expectedReturnDate} at {selectedOutpass.expectedReturnTime}</span>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-2 flex items-center justify-between">
                <div>
                  <span className="text-gray-400 block text-[10px]">Current Status</span>
                  {getStatusBadge(selectedOutpass.status)}
                </div>
                <div className="text-right">
                  <span className="text-gray-400 block text-[10px]">Submitted On</span>
                  <span className="text-gray-700 font-mono text-[11px]">{selectedOutpass.submissionDate}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-gray-100">
              <button
                onClick={() => setSelectedOutpass(null)}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
